# Panduan Firebase & Web Admin Control (ACEL SETTINGS IOS)

Sistem lisensi aplikasi Anda kini telah resmi terintegrasi dengan **Firebase Realtime Database REST API**. Anda tidak perlu lagi menggunakan key testing manual, dan dapat mengontrol semua key secara live dari web admin dashboard yang telah disediakan.

---

## 1. Cara Bikin Firebase Realtime Database Gratis (Hanya 2 Menit)

1. Buka [console.firebase.google.com](https://console.firebase.google.com) lalu login dengan akun Google Anda.
2. Klik **Add project** (Tambah proyek) &rarr; beri nama proyek (misal: `acel-settings-ios`) &rarr; klik **Continue** sampai selesai.
3. Di menu sidebar sebelah kiri, klik menu **Build** &rarr; pilih **Realtime Database**.
4. Klik tombol **Create Database**:
   - Pilih lokasi server: **Singapore (asia-southeast1)** atau **United States (us-central1)**.
   - Pada pilihan Security rules, pilih **Start in test mode** lalu klik **Enable**.
5. Salin URL database Anda yang muncul di bagian atas tabel.  
   Bentuknya seperti ini:
   ```text
   https://NAMA-PROYEK-default-rtdb.firebaseio.com
   ```

---

## 2. Setting Rules Firebase (Agar Admin & App Bisa Mengakses)

1. Di halaman Realtime Database pada Firebase Console, klik tab **Rules** di bagian atas.
2. Ganti seluruh kodenya dengan aturan di bawah ini:
   ```json
   {
     "rules": {
       "keys": {
         ".read": true,
         ".write": true
       }
     }
   }
   ```
3. Klik tombol **Publish**.

---

## 3. Cara Menggunakan Web Admin Control (`admin_panel.html`)

Kami sudah membuatkan dashboard web admin khusus bergaya cyberpunk yang siap pakai. File ini berada di:
👉 `D:\Downloads\admin_panel.html`

### Cara Pakai:
1. Klik 2x file `admin_panel.html` di folder Downloads komputer Anda (otomatis terbuka di Chrome / Edge).
2. Di pojok kanan atas, masukkan URL Firebase Realtime Database Anda, lalu klik **CONNECT**.
3. Status akan berubah menjadi hijau: **Terhubung ke Firebase Realtime Database**.

### Fitur Web Admin:
- **Generate Key Acak Otomatis**:
  - Format resmi: `ACEL-IOS-XXXXX` (contoh: `ACEL-IOS-84912`).
  - Bisa isi Nama Pembeli (misal: "Noel VIP").
  - Pilihan durasi masa aktif: 1 Hari, 3 Hari, 7 Hari, 14 Hari, 30 Hari, 60 Hari, 365 Hari, atau Lifetime (Permanen).
  - Klik **GENERATE & SIMPAN** &rarr; key langsung tersimpan ke Firebase dan tombol **SALIN KEY** muncul.
- **Monitoring Device Real-time**:
  - Tabel otomatis menampilkan semua key yang pernah dibuat.
  - Menampilkan status: `BELUM DIPAKAI`, `AKTIF` (lengkap dengan tipe iPhone, versi iOS, dan ID perangkat), `EXPIRED`, atau `BANNED`.
- **Aksi Cepat Admin**:
  - **🔓 Reset HWID**: Jika pembeli ganti HP dan izin ke Anda, klik tombol ini agar key bisa dipakai di HP barunya.
  - **Ban / Unban**: Nonaktifkan akses user seketika jika mereka melanggar.
  - **+30h**: Menambah masa aktif 30 hari langsung dari web.
  - **🗑 Hapus**: Menghapus key permanen.

---

## 4. Mekanisme 1 Key 1 Device di iPhone

1. Pembeli memasukkan key di aplikasi iOS (`ACEL-IOS-XXXXX`).
2. Aplikasi menghubungi Firebase via REST API:
   - Jika key belum pernah dipakai: UUID iPhone pembeli akan otomatis dikunci ke key tersebut di database.
   - Jika key dicoba dimasukkan di iPhone lain: Aplikasi langsung menolak dengan notifikasi *"Key ini sudah terkunci di iPhone lain! (1 Key 1 Device)"*.
   - Jika masa aktif habis: Aplikasi otomatis menolak dengan notifikasi *"Masa aktif key ini sudah KADALUARSA!"*.
