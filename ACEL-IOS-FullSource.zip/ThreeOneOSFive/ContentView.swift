// ThreeOneOSFive/ContentView.swift
// ACEL IOS — Screen 2: Main Dashboard
// 1:1 Accurate Replication of HTML Cyberpunk Design

import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var licenseManager: LicenseManager
    @ObservedObject private var engine = AcelTuningEngine.shared
    @State private var showSettings = false

    var body: some View {
        ZStack {
            // Background #08080A
            AppTheme.iosDark
                .ignoresSafeArea()

            VStack(spacing: 0) {
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 14) {
                        // MARK: - 2. Header: ACEL IOS & Controls
                        headerBar
                            .padding(.top, 8)

                        // MARK: - 3. Card: Device Status
                        deviceStatusCard

                        // MARK: - 4. Card: Optimize IOS
                        optimizeCard

                        // MARK: - 5. Card: Adjust Tracking
                        trackingCard

                        // MARK: - 6. Card: Adjust Easy Drag (Kelicinan Layar)
                        easyDragCard

                        // MARK: - 6B. Card: Unlock 144 FPS Ultra Switch
                        fps144SwitchCard

                        // MARK: - 7. Section: Dual Game Launcher (FF & FF MAX)
                        clientLauncherSection

                        // MARK: - 8. Card: Join Channel WhatsApp
                        whatsappChannelCard

                        // MARK: - 9. Footer: Developer By Hanx
                        footerSection
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 32)
                }
            }

            // MARK: - In-App Floating Dynamic Island Notification
            if engine.showToast, let msg = engine.toastMessage {
                VStack {
                    HStack {
                        Text(msg)
                            .font(.system(size: 12, weight: .semibold, design: .monospaced))
                            .foregroundStyle(.white)
                        Spacer()
                        Text("ACEL-OS")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundStyle(AppTheme.iosRed)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .fill(engine.toastIsError ? Color(red: 0.35, green: 0.05, blue: 0.08).opacity(0.95) : Color(red: 26/255, green: 26/255, blue: 34/255).opacity(0.95))
                            .overlay(
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .stroke(AppTheme.iosRed.opacity(0.35), lineWidth: 1)
                            )
                    )
                    .shadow(color: Color.black.opacity(0.6), radius: 16, x: 0, y: 8)
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                    Spacer()
                }
                .transition(.move(edge: .top).combined(with: .opacity))
                .animation(.easeInOut(duration: 0.25), value: engine.showToast)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
    }

    // MARK: - 2. Header
    private var headerBar: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("ACEL IOS")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(.white)

                Text("ACEL SETTINGS IOS")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .tracking(1.7)
                    .foregroundStyle(AppTheme.iosRed)
            }

            Spacer()

            HStack(spacing: 8) {
                // Logout Button
                Button {
                    licenseManager.deactivate()
                    engine.showToast("Telah keluar dari Control Center", isError: false)
                } label: {
                    ZStack {
                        Circle()
                            .fill(Color.white.opacity(0.05))
                            .frame(width: 36, height: 36)
                            .overlay(Circle().stroke(Color.white.opacity(0.1), lineWidth: 1))
                        Image(systemName: "rectangle.portrait.and.arrow.right")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(Color.white.opacity(0.8))
                    }
                }
                .buttonStyle(.plain)

                // Settings Gear Button
                Button {
                    showSettings = true
                } label: {
                    ZStack {
                        Circle()
                            .fill(AppTheme.iosRedMuted)
                            .frame(width: 36, height: 36)
                            .overlay(Circle().stroke(AppTheme.iosRed.opacity(0.35), lineWidth: 1))
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundStyle(AppTheme.iosRed)
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 4)
    }

    // MARK: - 3. Device Status Card
    private var deviceStatusCard: some View {
        VStack(spacing: 12) {
            HStack(spacing: 6) {
                Image(systemName: "shield.fill")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(AppTheme.iosRed)
                Text("DEVICE STATUS")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .tracking(1.4)
                    .foregroundStyle(AppTheme.iosRed)
                Spacer()
            }

            VStack(spacing: 10) {
                // iOS Version
                HStack {
                    HStack(spacing: 8) {
                        Image(systemName: "apple.logo")
                            .font(.system(size: 13))
                            .foregroundStyle(.white)
                        Text("iOS")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(Color.white.opacity(0.85))
                    }
                    Spacer()
                    Text(AppInfo.osVersion)
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .foregroundStyle(.white)
                }

                // Device Model
                HStack {
                    HStack(spacing: 8) {
                        Image(systemName: "iphone")
                            .font(.system(size: 13))
                            .foregroundStyle(Color.white.opacity(0.6))
                        Text("Device")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(Color.white.opacity(0.85))
                    }
                    Spacer()
                    Text(AppInfo.displayMachineName)
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .foregroundStyle(.white)
                }

                Divider()
                    .background(Color.white.opacity(0.08))

                // Support Status
                HStack {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.seal.fill")
                            .font(.system(size: 13))
                            .foregroundStyle(AppTheme.emerald)
                        Text("Support")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(Color.white.opacity(0.85))
                    }
                    Spacer()
                    HStack(spacing: 5) {
                        Circle()
                            .fill(AppTheme.emerald)
                            .frame(width: 6, height: 6)
                        Text("SUPPORTED")
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .tracking(1.2)
                            .foregroundStyle(AppTheme.emerald)
                    }
                }
            }
        }
        .padding(16)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 4. Optimize IOS Card
    private var optimizeCard: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(AppTheme.iosRedMuted)
                    .frame(width: 40, height: 40)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(AppTheme.iosRed.opacity(0.2), lineWidth: 1)
                    )
                Image(systemName: "bolt.fill")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(AppTheme.iosRed)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text("Optimize IOS")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(.white)
                Text("Kernel Booster & Touch Latency")
                    .font(.system(size: 11))
                    .foregroundStyle(Color.white.opacity(0.55))
            }

            Spacer()

            Toggle("", isOn: $engine.isOptimizeActive)
                .labelsHidden()
                .tint(AppTheme.iosRed)
        }
        .padding(14)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 5. Adjust Tracking Card
    private var trackingCard: some View {
        VStack(spacing: 12) {
            HStack {
                HStack(spacing: 10) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(AppTheme.iosRedMuted)
                            .frame(width: 28, height: 28)
                        Image(systemName: "scope")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(AppTheme.iosRed)
                    }

                    VStack(alignment: .leading, spacing: 1) {
                        Text("Adjust Tracking")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.white)
                        Text("Anti-Body Lock • Vertical Lift")
                            .font(.system(size: 10))
                            .foregroundStyle(Color.white.opacity(0.55))
                    }
                }

                Spacer()

                // Badge Level Readout
                Text(engine.trackingBadgeText)
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(AppTheme.iosRed)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 3)
                    .background(AppTheme.iosRedMuted)
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
            }

            // Slider
            VStack(spacing: 4) {
                Slider(value: $engine.trackingValue, in: 10...100, step: 1)
                    .tint(AppTheme.iosRed)

                HStack {
                    Text("10% (Anti-Lock)")
                    Spacer()
                    Text("35% (Rekomendasi)")
                        .foregroundStyle(AppTheme.iosRed.opacity(0.85))
                    Spacer()
                    Text("100% (Lock)")
                        .foregroundStyle(Color.white.opacity(0.4))
                }
                .font(.system(size: 9.5, design: .monospaced))
                .foregroundStyle(Color.white.opacity(0.4))
            }
        }
        .padding(16)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 6. Adjust Easy Drag (Kelicinan Layar)
    private var easyDragCard: some View {
        VStack(spacing: 12) {
            HStack {
                HStack(spacing: 10) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(AppTheme.iosRedMuted)
                            .frame(width: 28, height: 28)
                        Image(systemName: "hand.draw.fill")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(AppTheme.iosRed)
                    }

                    VStack(alignment: .leading, spacing: 1) {
                        Text("Adjust Easy Drag")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.white)
                        Text("Ultra Touch Frictionless Drag")
                            .font(.system(size: 10))
                            .foregroundStyle(Color.white.opacity(0.55))
                    }
                }

                Spacer()

                // Badge Level Readout
                Text(engine.dragBadgeText)
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(AppTheme.iosRed)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 3)
                    .background(AppTheme.iosRedMuted)
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
            }

            // Slider
            VStack(spacing: 4) {
                Slider(value: $engine.dragValue, in: 20...100, step: 1)
                    .tint(AppTheme.iosRed)

                HStack {
                    Text("20% (Enteng)")
                    Spacer()
                    Text("50% (Smooth)")
                    Spacer()
                    Text("85% (Super)")
                    Spacer()
                    Text("100% (Gacor)")
                        .foregroundStyle(AppTheme.iosRed)
                        .fontWeight(.bold)
                }
                .font(.system(size: 9.5, design: .monospaced))
                .foregroundStyle(Color.white.opacity(0.4))
            }
        }
        .padding(16)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 6B. Unlock 144 FPS Ultra Switch Card
    private var fps144SwitchCard: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .fill(AppTheme.iosRedMuted)
                    .frame(width: 32, height: 32)
                Image(systemName: "bolt.badge.clock.fill")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(AppTheme.iosRed)
            }

            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text("Unlock 144 FPS Ultra")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.white)
                    if engine.is144FPSActive {
                        Text("ACTIVE")
                            .font(.system(size: 8.5, weight: .bold, design: .monospaced))
                            .foregroundStyle(AppTheme.emerald)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 1.5)
                            .background(AppTheme.emerald.opacity(0.12))
                            .clipShape(Capsule())
                    }
                }
                Text("Bypass Frame Cap • FF Biasa & FF MAX")
                    .font(.system(size: 10))
                    .foregroundStyle(Color.white.opacity(0.55))
            }

            Spacer()

            Toggle("", isOn: $engine.is144FPSActive)
                .labelsHidden()
                .tint(AppTheme.iosRed)
        }
        .padding(14)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(engine.is144FPSActive ? AppTheme.iosRed.opacity(0.35) : Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 7. Dual Game Launcher (FF & FF MAX)
    private var clientLauncherSection: some View {
        VStack(spacing: 8) {
            HStack {
                HStack(spacing: 6) {
                    Circle()
                        .fill(AppTheme.iosRed)
                        .frame(width: 6, height: 6)
                    Text("SELECT TARGET CLIENT")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .tracking(1.4)
                        .foregroundStyle(Color.white.opacity(0.7))
                }
                Spacer()
                Text("v1.108.x")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(Color.white.opacity(0.4))
            }
            .padding(.horizontal, 4)

            HStack(spacing: 10) {
                // 7A. Free Fire (Biasa)
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        ZStack {
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .fill(LinearGradient(colors: [Color(red: 31/255, green: 24/255, blue: 27/255), Color(red: 18/255, green: 11/255, blue: 14/255)], startPoint: .topLeading, endPoint: .bottomTrailing))
                                .frame(width: 40, height: 40)
                                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
                            Text("FF")
                                .font(.system(size: 14, weight: .black, design: .rounded))
                                .italic()
                                .foregroundStyle(.white)
                        }
                        Spacer()
                        Text("STD")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundStyle(Color.white.opacity(0.55))
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.white.opacity(0.06))
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Free Fire")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.white)
                        if engine.is144FPSActive {
                            HStack(spacing: 4) {
                                Circle().fill(AppTheme.emerald).frame(width: 4, height: 4)
                                Text("144 FPS Unlocked")
                                    .font(.system(size: 9, weight: .semibold, design: .monospaced))
                                    .foregroundStyle(AppTheme.emerald)
                            }
                        } else {
                            Text("Original Edition")
                                .font(.system(size: 9))
                                .foregroundStyle(Color.white.opacity(0.5))
                        }
                    }

                    Button {
                        engine.applyTweaksToTarget(bundleID: "com.dts.freefireth", name: "Free Fire", scheme: "freefire")
                    } label: {
                        HStack(spacing: 6) {
                            Text("LAUNCH")
                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                                .tracking(1)
                            Image(systemName: "play.fill")
                                .font(.system(size: 9))
                        }
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 9)
                        .background(Color.white.opacity(0.08))
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.white.opacity(0.12), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
                .padding(12)
                .background(AppTheme.iosCard)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Color.white.opacity(0.06), lineWidth: 1))

                // 7B. Free Fire MAX
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        ZStack {
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .fill(Color.black)
                                .frame(width: 40, height: 40)
                                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(AppTheme.iosRed.opacity(0.6), lineWidth: 1))
                            Text("MAX")
                                .font(.system(size: 13, weight: .black, design: .rounded))
                                .italic()
                                .foregroundStyle(AppTheme.iosRed)
                        }
                        Spacer()
                        Text("ULTRA")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundStyle(AppTheme.iosRed)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(AppTheme.iosRedMuted)
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                            .overlay(RoundedRectangle(cornerRadius: 6).stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Free Fire MAX")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.white)
                        if engine.is144FPSActive {
                            HStack(spacing: 4) {
                                Circle().fill(AppTheme.iosRed).frame(width: 4, height: 4)
                                Text("144 FPS Ultra Max")
                                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                                    .foregroundStyle(AppTheme.iosRed)
                            }
                        } else {
                            HStack(spacing: 4) {
                                Circle().fill(AppTheme.emerald).frame(width: 4, height: 4)
                                Text("HD Textures")
                                    .font(.system(size: 9, weight: .semibold, design: .monospaced))
                                    .foregroundStyle(AppTheme.emerald)
                            }
                        }
                    }

                    Button {
                        engine.applyTweaksToTarget(bundleID: "com.dts.freefiremax", name: "Free Fire MAX", scheme: "freefiremax")
                    } label: {
                        HStack(spacing: 6) {
                            Text("LAUNCH")
                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                                .tracking(1)
                            Image(systemName: "play.fill")
                                .font(.system(size: 9))
                        }
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 9)
                        .background(
                            LinearGradient(colors: [AppTheme.iosRed, AppTheme.iosRedDark], startPoint: .leading, endPoint: .trailing)
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .shadow(color: AppTheme.iosRed.opacity(0.4), radius: 8, x: 0, y: 2)
                    }
                    .buttonStyle(.plain)
                }
                .padding(12)
                .background(AppTheme.iosCard)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
            }
        }
    }

    // MARK: - 8. Join Channel WhatsApp Card
    private var whatsappChannelCard: some View {
        Button {
            if let url = URL(string: "https://whatsapp.com/channel/0029Vb6i1yu9RZAVv3zpDn3w") {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        } label: {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(AppTheme.emerald.opacity(0.12))
                        .frame(width: 40, height: 40)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(AppTheme.emerald.opacity(0.25), lineWidth: 1)
                        )
                    Image(systemName: "message.fill")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(AppTheme.emerald)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text("Join Chanel Whatsaap")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.white)
                    Text("Dapatkan update patch terbaru")
                        .font(.system(size: 10))
                        .foregroundStyle(Color.white.opacity(0.5))
                }

                Spacer()

                Image(systemName: "arrow.up.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Color.white.opacity(0.4))
            }
            .padding(14)
            .background(AppTheme.iosCard)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.white.opacity(0.08), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: - 9. Footer
    private var footerSection: some View {
        HStack(spacing: 4) {
            Text("DEVELOPER BY")
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .tracking(1.4)
                .foregroundStyle(Color.white.opacity(0.45))
            Text("HANX")
                .font(.system(size: 11, weight: .black, design: .monospaced))
                .tracking(1.4)
                .foregroundStyle(AppTheme.iosRed)
        }
        .padding(.top, 8)
    }
}
