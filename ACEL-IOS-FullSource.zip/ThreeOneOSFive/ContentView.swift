// ThreeOneOSFive/ContentView.swift
// ACEL IOS — Screen 2: Main Dashboard
// 1:1 Accurate Replication of HTML Cyberpunk Design

import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var licenseManager: LicenseManager
    @ObservedObject private var engine = AcelTuningEngine.shared
    @State private var showSettings = false

    var body: some View {
        ZStack {
            // Background #08080A
            AppTheme.iosDark
                .ignoresSafeArea()

            VStack(spacing: 0) {
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 14) {
                        // MARK: - 2. Header: ACEL IOS & Controls
                        headerBar
                            .padding(.top, 8)

                        // MARK: - 3. Card: Device Status
                        deviceStatusCard

                        // MARK: - 4. Card: Optimize IOS
                        optimizeCard

                        // MARK: - 5. Card: Adjust Tracking
                        trackingCard

                        // MARK: - 6. Card: Adjust Easy Drag (Kelicinan Layar)
                        easyDragCard

                        // MARK: - 7. Section: Dual Game Launcher (FF & FF MAX)
                        clientLauncherSection

                        // MARK: - 8. Card: Join Channel WhatsApp
                        whatsappChannelCard

                        // MARK: - 9. Footer: Developer By Hanx
                        footerSection
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 32)
                }
            }

            // MARK: - In-App Floating Dynamic Island Notification
            if engine.showToast, let msg = engine.toastMessage {
                VStack {
                    HStack {
                        Text(msg)
                            .font(.system(size: 12, weight: .semibold, design: .monospaced))
                            .foregroundStyle(.white)
                        Spacer()
                        Text("ACEL-OS")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundStyle(AppTheme.iosRed)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .fill(engine.toastIsError ? Color(red: 0.35, green: 0.05, blue: 0.08).opacity(0.95) : Color(red: 26/255, green: 26/255, blue: 34/255).opacity(0.95))
                            .overlay(
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .stroke(AppTheme.iosRed.opacity(0.35), lineWidth: 1)
                            )
                    )
                    .shadow(color: Color.black.opacity(0.6), radius: 16, x: 0, y: 8)
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                    Spacer()
                }
                .transition(.move(edge: .top).combined(with: .opacity))
                .animation(.easeInOut(duration: 0.25), value: engine.showToast)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
    }

    // MARK: - 2. Header
    private var headerBar: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("ACEL IOS")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(.white)

                Text("ACEL SETTINGS IOS")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .tracking(1.7)
                    .foregroundStyle(AppTheme.iosRed)
            }

            Spacer()

            HStack(spacing: 8) {
                // Logout Button
                Button {
                    licenseManager.deactivate()
                    engine.showToast("Telah keluar dari Control Center", isError: false)
                } label: {
                    ZStack {
                        Circle()
                            .fill(Color.white.opacity(0.05))
                            .frame(width: 36, height: 36)
                            .overlay(Circle().stroke(Color.white.opacity(0.1), lineWidth: 1))
                        Image(systemName: "rectangle.portrait.and.arrow.right")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(Color.white.opacity(0.8))
                    }
                }
                .buttonStyle(.plain)

                // Settings Gear Button
                Button {
                    showSettings = true
                } label: {
                    ZStack {
                        Circle()
                            .fill(AppTheme.iosRedMuted)
                            .frame(width: 36, height: 36)
                            .overlay(Circle().stroke(AppTheme.iosRed.opacity(0.35), lineWidth: 1))
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundStyle(AppTheme.iosRed)
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 4)
    }

    // MARK: - 3. Device Status Card
    private var deviceStatusCard: some View {
        VStack(spacing: 12) {
            HStack(spacing: 6) {
                Image(systemName: "shield.fill")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(AppTheme.iosRed)
                Text("DEVICE STATUS")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .tracking(1.4)
                    .foregroundStyle(AppTheme.iosRed)
                Spacer()
            }

            VStack(spacing: 10) {
                // iOS Version
                HStack {
                    HStack(spacing: 8) {
                        Image(systemName: "apple.logo")
                            .font(.system(size: 13))
                            .foregroundStyle(.white)
                        Text("iOS")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(Color.white.opacity(0.85))
                    }
                    Spacer()
                    Text(AppInfo.osVersion)
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .foregroundStyle(.white)
                }

                // Device Model
                HStack {
                    HStack(spacing: 8) {
                        Image(systemName: "iphone")
                            .font(.system(size: 13))
                            .foregroundStyle(Color.white.opacity(0.6))
                        Text("Device")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(Color.white.opacity(0.85))
                    }
                    Spacer()
                    Text(AppInfo.displayMachineName)
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .foregroundStyle(.white)
                }

                Divider()
                    .background(Color.white.opacity(0.08))

                // Support Status
                HStack {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.seal.fill")
                            .font(.system(size: 13))
                            .foregroundStyle(AppTheme.emerald)
                        Text("Support")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(Color.white.opacity(0.85))
                    }
                    Spacer()
                    HStack(spacing: 5) {
                        Circle()
                            .fill(AppTheme.emerald)
                            .frame(width: 6, height: 6)
                        Text("SUPPORTED")
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .tracking(1.2)
                            .foregroundStyle(AppTheme.emerald)
                    }
                }
            }
        }
        .padding(16)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 4. Optimize IOS Card
    private var optimizeCard: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(AppTheme.iosRedMuted)
                    .frame(width: 40, height: 40)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(AppTheme.iosRed.opacity(0.2), lineWidth: 1)
                    )
                Image(systemName: "bolt.fill")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(AppTheme.iosRed)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text("Optimize IOS")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(.white)
                Text("Kernel Booster & Touch Latency")
                    .font(.system(size: 11))
                    .foregroundStyle(Color.white.opacity(0.55))
            }

            Spacer()

            Toggle("", isOn: $engine.isOptimizeActive)
                .labelsHidden()
                .tint(AppTheme.iosRed)
        }
        .padding(14)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 5. Adjust Tracking Card
    private var trackingCard: some View {
        VStack(spacing: 12) {
            HStack {
                HStack(spacing: 10) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(AppTheme.iosRedMuted)
                            .frame(width: 28, height: 28)
                        Image(systemName: "scope")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(AppTheme.iosRed)
                    }

                    VStack(alignment: .leading, spacing: 1) {
                        Text("Adjust Tracking")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.white)
                        Text("Headshot Reticle Precision")
                            .font(.system(size: 10))
                            .foregroundStyle(Color.white.opacity(0.5))
                    }
                }

                Spacer()

                // Badge Level Readout
                Text(engine.trackingBadgeText)
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundStyle(AppTheme.iosRed)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 3)
                    .background(AppTheme.iosRedMuted)
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
            }

            // Slider
            VStack(spacing: 4) {
                Slider(value: $engine.trackingValue, in: 10...100, step: 1)
                    .tint(AppTheme.iosRed)

                HStack {
                    Text("Min (10%)")
                    Spacer()
                    Text("Balanced")
                    Spacer()
                    Text("Max (100%)")
                        .foregroundStyle(AppTheme.iosRed)
                }
                .font(.system(size: 10, design: .monospaced))
                .foregroundStyle(Color.white.opacity(0.4))
            }
        }
        .padding(16)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 6. Adjust Easy Drag (Kelicinan Layar)
    private var easyDragCard: some View {
        VStack(spacing: 14) {
            HStack {
                HStack(spacing: 10) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .fill(
                                LinearGradient(
                                    colors: [AppTheme.iosRed.opacity(0.35), AppTheme.iosRedDark.opacity(0.2)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 32, height: 32)
                            .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(AppTheme.iosRed.opacity(0.4), lineWidth: 1))
                        Image(systemName: "flame.fill")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundStyle(AppTheme.iosRed)
                    }

                    VStack(alignment: .leading, spacing: 1) {
                        Text("Adjust Easy Drag")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.white)
                        Text("Zero Friction | Hyper Touch")
                            .font(.system(size: 10))
                            .foregroundStyle(Color.white.opacity(0.55))
                    }
                }

                Spacer()

                // Badge Level Readout with Multiplier
                Text(engine.dragBadgeText)
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(AppTheme.iosRed)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(AppTheme.iosRedMuted)
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(AppTheme.iosRed.opacity(0.4), lineWidth: 1))
            }

            // Slider & Preset Ticks
            VStack(spacing: 6) {
                Slider(value: $engine.dragValue, in: 20...100, step: 1)
                    .tint(AppTheme.iosRed)

                HStack {
                    Text("20% (9x)")
                    Spacer()
                    Text("50% (16x)")
                    Spacer()
                    Text("80% (21x)")
                        .foregroundStyle(AppTheme.iosRed.opacity(0.85))
                        .fontWeight(.semibold)
                    Spacer()
                    Text("100% (25x)")
                        .foregroundStyle(AppTheme.iosRed)
                        .fontWeight(.bold)
                }
                .font(.system(size: 9.5, design: .monospaced))
                .foregroundStyle(Color.white.opacity(0.45))
            }

            // Live Stat Info Bar
            HStack(spacing: 8) {
                HStack(spacing: 4) {
                    Circle().fill(AppTheme.emerald).frame(width: 5, height: 5)
                    Text("Touch Engine: 120Hz")
                        .font(.system(size: 9.5, weight: .semibold, design: .monospaced))
                        .foregroundStyle(AppTheme.emerald)
                }
                Spacer()
                Text("Zero Damping Active")
                    .font(.system(size: 9.5, weight: .bold, design: .monospaced))
                    .foregroundStyle(AppTheme.iosRed)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Color.black.opacity(0.35))
            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
        }
        .padding(16)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(AppTheme.iosRed.opacity(0.2), lineWidth: 1)
        )
    }

    // MARK: - 7. Dual Game Launcher (FF & FF MAX)
    private var clientLauncherSection: some View {
        VStack(spacing: 10) {
            HStack {
                HStack(spacing: 6) {
                    Circle()
                        .fill(AppTheme.iosRed)
                        .frame(width: 6, height: 6)
                        .shadow(color: AppTheme.iosRed, radius: 4)
                    Text("TARGET GAME CLIENT")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .tracking(1.4)
                        .foregroundStyle(Color.white.opacity(0.85))
                }
                Spacer()
                Text("v1.108.x - ULTRA")
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundStyle(AppTheme.iosRed.opacity(0.8))
            }
            .padding(.horizontal, 4)

            HStack(spacing: 10) {
                // 7A. Free Fire (Standard)
                VStack(alignment: .leading, spacing: 12) {
                    HStack(alignment: .top) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .fill(
                                    LinearGradient(
                                        colors: [Color(red: 35/255, green: 22/255, blue: 24/255), Color(red: 16/255, green: 10/255, blue: 12/255)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 42, height: 42)
                                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(AppTheme.iosRed.opacity(0.5), lineWidth: 1.2))
                                .shadow(color: AppTheme.iosRed.opacity(0.25), radius: 6)

                            VStack(spacing: -2) {
                                Text("FF")
                                    .font(.system(size: 16, weight: .black, design: .rounded))
                                    .italic()
                                    .foregroundStyle(.white)
                            }
                        }

                        Spacer()

                        Text("ORIGINAL")
                            .font(.system(size: 8.5, weight: .bold, design: .monospaced))
                            .foregroundStyle(Color.white.opacity(0.7))
                            .padding(.horizontal, 6)
                            .padding(.vertical, 3)
                            .background(Color.white.opacity(0.08))
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                            .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color.white.opacity(0.12), lineWidth: 0.8))
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Free Fire")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white)
                        HStack(spacing: 4) {
                            Circle().fill(AppTheme.emerald).frame(width: 4, height: 4)
                            Text("120Hz Touch | 21x Slick")
                                .font(.system(size: 9, weight: .medium, design: .monospaced))
                                .foregroundStyle(AppTheme.emerald)
                        }
                    }

                    Button {
                        engine.applyTweaksToTarget(bundleID: "com.dts.freefireth", name: "Free Fire", scheme: "freefire")
                    } label: {
                        HStack(spacing: 6) {
                            Text("LAUNCH STD")
                                .font(.system(size: 11, weight: .black, design: .monospaced))
                                .tracking(0.8)
                            Image(systemName: "bolt.fill")
                                .font(.system(size: 10))
                        }
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(
                            LinearGradient(
                                colors: [Color(red: 45/255, green: 18/255, blue: 22/255), Color(red: 25/255, green: 10/255, blue: 14/255)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(AppTheme.iosRed.opacity(0.5), lineWidth: 1)
                        )
                        .shadow(color: AppTheme.iosRed.opacity(0.2), radius: 6, x: 0, y: 2)
                    }
                    .buttonStyle(.plain)
                }
                .padding(14)
                .background(AppTheme.iosCard)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .stroke(AppTheme.iosRed.opacity(0.25), lineWidth: 1)
                )

                // 7B. Free Fire MAX
                VStack(alignment: .leading, spacing: 12) {
                    HStack(alignment: .top) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .fill(
                                    LinearGradient(
                                        colors: [Color.black, Color(red: 30/255, green: 8/255, blue: 12/255)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 42, height: 42)
                                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(AppTheme.iosRed, lineWidth: 1.5))
                                .shadow(color: AppTheme.iosRed.opacity(0.4), radius: 8)

                            Text("MAX")
                                .font(.system(size: 13, weight: .black, design: .rounded))
                                .italic()
                                .foregroundStyle(AppTheme.iosRed)
                        }

                        Spacer()

                        Text("ULTRA HD")
                            .font(.system(size: 8.5, weight: .bold, design: .monospaced))
                            .foregroundStyle(AppTheme.iosRed)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 3)
                            .background(AppTheme.iosRedMuted)
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                            .overlay(RoundedRectangle(cornerRadius: 6).stroke(AppTheme.iosRed.opacity(0.4), lineWidth: 1))
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Free Fire MAX")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white)
                        HStack(spacing: 4) {
                            Circle().fill(AppTheme.iosRed).frame(width: 4, height: 4)
                            Text("Godly 25x | Zero Lag")
                                .font(.system(size: 9, weight: .bold, design: .monospaced))
                                .foregroundStyle(AppTheme.iosRed)
                        }
                    }

                    Button {
                        engine.applyTweaksToTarget(bundleID: "com.dts.freefiremax", name: "Free Fire MAX", scheme: "freefiremax")
                    } label: {
                        HStack(spacing: 6) {
                            Text("LAUNCH MAX")
                                .font(.system(size: 11, weight: .black, design: .monospaced))
                                .tracking(0.8)
                            Image(systemName: "flame.fill")
                                .font(.system(size: 10))
                        }
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(
                            LinearGradient(
                                colors: [AppTheme.iosRed, AppTheme.iosRedDark],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .shadow(color: AppTheme.iosRed.opacity(0.55), radius: 10, x: 0, y: 3)
                    }
                    .buttonStyle(.plain)
                }
                .padding(14)
                .background(AppTheme.iosCard)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .stroke(AppTheme.iosRed.opacity(0.45), lineWidth: 1.2)
                )
            }
        }
    }

    // MARK: - 8. Join Channel WhatsApp Card
    private var whatsappChannelCard: some View {
        Button {
            if let url = URL(string: "https://whatsapp.com/channel/0029Vb6i1yu9RZAVv3zpDn3w") {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        } label: {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(AppTheme.emerald.opacity(0.12))
                        .frame(width: 40, height: 40)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(AppTheme.emerald.opacity(0.25), lineWidth: 1)
                        )
                    Image(systemName: "message.fill")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(AppTheme.emerald)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text("Join Chanel Whatsaap")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.white)
                    Text("Dapatkan update patch terbaru")
                        .font(.system(size: 10))
                        .foregroundStyle(Color.white.opacity(0.5))
                }

                Spacer()

                Image(systemName: "arrow.up.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Color.white.opacity(0.4))
            }
            .padding(14)
            .background(AppTheme.iosCard)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.white.opacity(0.08), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: - 9. Footer
    private var footerSection: some View {
        HStack(spacing: 4) {
            Text("DEVELOPER BY")
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .tracking(1.4)
                .foregroundStyle(Color.white.opacity(0.45))
            Text("HANX")
                .font(.system(size: 11, weight: .black, design: .monospaced))
                .tracking(1.4)
                .foregroundStyle(AppTheme.iosRed)
        }
        .padding(.top, 8)
    }
}
