// ThreeOneOSFive/ContentView.swift
// ACEL IOS — Screen 2: Main Dashboard
// 1:1 Accurate Replication of HTML Cyberpunk Design with Grafik MC Dialog & Dual Launcher

import SwiftUI
import UIKit

enum TargetClientType: Identifiable {
    case standard
    case max
    
    var id: String { bundleID }
    
    var displayName: String {
        switch self {
        case .standard: return "Free Fire"
        case .max: return "Free Fire MAX"
        }
    }
    
    var bundleID: String {
        switch self {
        case .standard: return "com.dts.freefireth"
        case .max: return "com.dts.freefiremax"
        }
    }
    
    var scheme: String {
        switch self {
        case .standard: return "freefire"
        case .max: return "freefiremax"
        }
    }
    
    var badgeLabel: String {
        switch self {
        case .standard: return "STD"
        case .max: return "ULTRA"
        }
    }
}

struct ContentView: View {
    @EnvironmentObject private var licenseManager: LicenseManager
    @ObservedObject private var engine = AcelTuningEngine.shared
    @State private var showSettings = false
    @State private var selectedClientForDialog: TargetClientType? = nil
    @State private var showGrafikMCDialog: Bool = false

    var body: some View {
        ZStack {
            // Background #08080A
            AppTheme.iosDark
                .ignoresSafeArea()

            VStack(spacing: 0) {
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 14) {
                        // MARK: - 2. Header: ACEL IOS & Controls
                        headerBar
                            .padding(.top, 8)

                        // MARK: - 3. Card: Device Status
                        deviceStatusCard

                        // MARK: - 4. Card: Optimize IOS
                        optimizeCard

                        // MARK: - 5. Card: Adjust Tracking
                        trackingCard

                        // MARK: - 6. Card: Adjust Easy Drag (Kelicinan Layar)
                        easyDragCard

                        // MARK: - 6B. Card: Unlock 144 FPS Ultra Switch
                        fps144SwitchCard

                        // MARK: - 6C. Card: Grafik MC (Potato Mode) Quick Panel
                        grafikMCQuickCard

                        // MARK: - 7. Section: Dual Game Launcher (FF & FF MAX)
                        clientLauncherSection

                        // MARK: - 8. Card: Join Channel WhatsApp
                        whatsappChannelCard

                        // MARK: - 9. Footer: Developer By Hanx
                        footerSection
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 32)
                }
            }

            // MARK: - Custom In-App Glassmorphism Dialog for Grafik MC
            if showGrafikMCDialog, let client = selectedClientForDialog {
                Color.black.opacity(0.7)
                    .ignoresSafeArea()
                    .transition(.opacity)
                    .onTapGesture {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            showGrafikMCDialog = false
                        }
                    }

                grafikMCDialogView(client: client)
                    .transition(.scale(scale: 0.9).combined(with: .opacity))
                    .padding(.horizontal, 20)
                    .zIndex(100)
            }

            // MARK: - In-App Floating Dynamic Island Notification
            if engine.showToast, let msg = engine.toastMessage {
                VStack {
                    HStack {
                        Text(msg)
                            .font(.system(size: 12, weight: .semibold, design: .monospaced))
                            .foregroundStyle(.white)
                        Spacer()
                        Text("ACEL-OS")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundStyle(AppTheme.iosRed)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .fill(engine.toastIsError ? Color(red: 0.35, green: 0.05, blue: 0.08).opacity(0.95) : Color(red: 26/255, green: 26/255, blue: 34/255).opacity(0.95))
                            .overlay(
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .stroke(AppTheme.iosRed.opacity(0.35), lineWidth: 1)
                            )
                    )
                    .shadow(color: Color.black.opacity(0.6), radius: 16, x: 0, y: 8)
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                    Spacer()
                }
                .transition(.move(edge: .top).combined(with: .opacity))
                .animation(.easeInOut(duration: 0.25), value: engine.showToast)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
    }

    // MARK: - 2. Header Bar
    private var headerBar: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 2) {
                Text("ACEL IOS")
                    .font(.system(size: 24, weight: .black, design: .monospaced))
                    .tracking(1.5)
                    .foregroundStyle(.white)
                Text("ACEL SETTINGS IOS")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .tracking(2.0)
                    .foregroundStyle(AppTheme.iosRed)
            }

            Spacer()

            HStack(spacing: 10) {
                Button {
                    licenseManager.deactivate()
                } label: {
                    ZStack {
                        Circle()
                            .fill(Color.white.opacity(0.08))
                            .frame(width: 40, height: 40)
                            .overlay(Circle().stroke(Color.white.opacity(0.12), lineWidth: 1))
                        Image(systemName: "rectangle.portrait.and.arrow.right")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(.white)
                    }
                }
                .buttonStyle(.plain)

                Button {
                    showSettings = true
                } label: {
                    ZStack {
                        Circle()
                            .fill(AppTheme.iosRedMuted)
                            .frame(width: 40, height: 40)
                            .overlay(Circle().stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(AppTheme.iosRed)
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 4)
    }

    // MARK: - 3. Device Status Card
    private var deviceStatusCard: some View {
        VStack(spacing: 12) {
            HStack(spacing: 6) {
                Circle()
                    .fill(AppTheme.iosRed)
                    .frame(width: 6, height: 6)
                Text("DEVICE STATUS")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .tracking(1.4)
                    .foregroundStyle(AppTheme.iosRed)
                Spacer()
            }

            VStack(spacing: 8) {
                HStack {
                    HStack(spacing: 8) {
                        Image(systemName: "apple.logo")
                            .font(.system(size: 14))
                            .foregroundStyle(.white)
                        Text("iOS")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(.white)
                    }
                    Spacer()
                    Text(UIDevice.current.systemVersion)
                        .font(.system(size: 13, weight: .bold, design: .monospaced))
                        .foregroundStyle(.white)
                }

                HStack {
                    HStack(spacing: 8) {
                        Image(systemName: "iphone")
                            .font(.system(size: 14))
                            .foregroundStyle(.white)
                        Text("Device")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(.white)
                    }
                    Spacer()
                    Text(deviceModelIdentifier())
                        .font(.system(size: 13, weight: .bold, design: .monospaced))
                        .foregroundStyle(.white)
                }
            }

            Rectangle()
                .fill(Color.white.opacity(0.08))
                .frame(height: 1)

            HStack {
                HStack(spacing: 6) {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 14))
                        .foregroundStyle(AppTheme.emerald)
                    Text("Support")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(.white)
                }
                Spacer()
                HStack(spacing: 6) {
                    Circle()
                        .fill(AppTheme.emerald)
                        .frame(width: 6, height: 6)
                    Text("SUPPORTED")
                        .font(.system(size: 12, weight: .black, design: .monospaced))
                        .foregroundStyle(AppTheme.emerald)
                }
            }
        }
        .padding(16)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 4. Optimize IOS Card
    private var optimizeCard: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(AppTheme.iosRedMuted)
                    .frame(width: 44, height: 44)
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
                Image(systemName: "bolt.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(AppTheme.iosRed)
            }

            VStack(alignment: .leading, spacing: 3) {
                Text("Optimize IOS")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
                Text("Kernel Booster & Touch Latency")
                    .font(.system(size: 11))
                    .foregroundStyle(Color.white.opacity(0.55))
            }

            Spacer()

            Toggle("", isOn: $engine.isOptimizeActive)
                .labelsHidden()
                .tint(AppTheme.iosRed)
        }
        .padding(14)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 5. Adjust Tracking Card
    private var trackingCard: some View {
        VStack(spacing: 12) {
            HStack(alignment: .center) {
                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(AppTheme.iosRedMuted)
                            .frame(width: 40, height: 40)
                            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
                        Image(systemName: "scope")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundStyle(AppTheme.iosRed)
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Adjust Tracking")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white)
                        Text("Anti-Body Lock • Vertical Lift")
                            .font(.system(size: 11))
                            .foregroundStyle(Color.white.opacity(0.55))
                    }
                }

                Spacer()

                Text(engine.trackingBadgeText)
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(AppTheme.iosRed)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(AppTheme.iosRedMuted)
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(AppTheme.iosRed.opacity(0.35), lineWidth: 1))
            }

            Slider(value: $engine.trackingValue, in: 10...100, step: 1)
                .tint(AppTheme.iosRed)

            HStack {
                Text("10% (Anti-Lock)")
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundStyle(Color.white.opacity(0.45))
                Spacer()
                Text("35% (Rekomendasi)")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(AppTheme.iosRed.opacity(0.85))
                Spacer()
                Text("100% (Lock)")
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundStyle(Color.white.opacity(0.45))
            }
        }
        .padding(14)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 6. Adjust Easy Drag Card
    private var easyDragCard: some View {
        VStack(spacing: 12) {
            HStack(alignment: .center) {
                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(AppTheme.iosRedMuted)
                            .frame(width: 40, height: 40)
                            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
                        Image(systemName: "hand.draw.fill")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundStyle(AppTheme.iosRed)
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Adjust Easy Drag")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white)
                        Text("Ultra Touch Frictionless Drag")
                            .font(.system(size: 11))
                            .foregroundStyle(Color.white.opacity(0.55))
                    }
                }

                Spacer()

                Text(engine.dragBadgeText)
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(AppTheme.iosRed)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(AppTheme.iosRedMuted)
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(AppTheme.iosRed.opacity(0.35), lineWidth: 1))
            }

            Slider(value: $engine.dragValue, in: 20...100, step: 1)
                .tint(AppTheme.iosRed)

            HStack {
                Text("20% (Enteng)")
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundStyle(Color.white.opacity(0.45))
                Spacer()
                Text("50% (Smooth)")
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundStyle(Color.white.opacity(0.45))
                Spacer()
                Text("85% (Super)")
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundStyle(Color.white.opacity(0.45))
                Spacer()
                Text("100% (Gacor)")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(AppTheme.iosRed)
            }
        }
        .padding(14)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 6B. Unlock 144 FPS Ultra Switch Card
    private var fps144SwitchCard: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(AppTheme.iosRedMuted)
                    .frame(width: 44, height: 44)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1)
                    )
                Image(systemName: "bolt.badge.clock.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(AppTheme.iosRed)
            }

            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text("Unlock 144 FPS Ultra")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(.white)
                    if engine.is144FPSActive {
                        Text("ACTIVE")
                            .font(.system(size: 8, weight: .black, design: .monospaced))
                            .foregroundStyle(AppTheme.emerald)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(AppTheme.emerald.opacity(0.15))
                            .clipShape(Capsule())
                    }
                }
                Text("Bypass Frame Cap • FF Biasa & FF MAX")
                    .font(.system(size: 11))
                    .foregroundStyle(Color.white.opacity(0.55))
            }

            Spacer()

            Toggle("", isOn: $engine.is144FPSActive)
                .labelsHidden()
                .tint(AppTheme.iosRed)
        }
        .padding(14)
        .background(AppTheme.iosCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(engine.is144FPSActive ? AppTheme.iosRed.opacity(0.35) : Color.white.opacity(0.08), lineWidth: 1)
        )
    }

    // MARK: - 6C. Grafik MC (Potato Mode) Quick Panel
    private var grafikMCQuickCard: some View {
        Button {
            selectedClientForDialog = .standard
            withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                showGrafikMCDialog = true
            }
        } label: {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.15) : Color.white.opacity(0.06))
                        .frame(width: 44, height: 44)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.4) : Color.white.opacity(0.12), lineWidth: 1)
                        )
                    Image(systemName: "cube.fill")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(engine.isGrafikMCActive ? AppTheme.emerald : Color.white.opacity(0.6))
                }

                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 6) {
                        Text("Grafik MC (Potato Mod)")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white)
                        if engine.isGrafikMCActive {
                            Text(engine.grafikMCBadgeText)
                                .font(.system(size: 8, weight: .bold, design: .monospaced))
                                .foregroundStyle(AppTheme.emerald)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(AppTheme.emerald.opacity(0.15))
                                .clipShape(Capsule())
                        }
                    }
                    Text("All Map Flat Kotak-Kotak • Tekan untuk Atur")
                        .font(.system(size: 11))
                        .foregroundStyle(Color.white.opacity(0.55))
                }

                Spacer()

                Toggle("", isOn: $engine.isGrafikMCActive)
                    .labelsHidden()
                    .tint(AppTheme.emerald)
            }
            .padding(14)
            .background(AppTheme.iosCard)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.35) : Color.white.opacity(0.08), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: - 7. Dual Game Launcher (FF & FF MAX)
    private var clientLauncherSection: some View {
        VStack(spacing: 8) {
            HStack {
                HStack(spacing: 6) {
                    Circle()
                        .fill(AppTheme.iosRed)
                        .frame(width: 6, height: 6)
                    Text("SELECT TARGET CLIENT")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .tracking(1.4)
                        .foregroundStyle(Color.white.opacity(0.7))
                }
                Spacer()
                Text("v1.108.x")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(Color.white.opacity(0.4))
            }
            .padding(.horizontal, 4)

            HStack(spacing: 10) {
                // 7A. Free Fire (Biasa) Card
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        ZStack {
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .fill(LinearGradient(colors: [Color(red: 31/255, green: 24/255, blue: 27/255), Color(red: 18/255, green: 11/255, blue: 14/255)], startPoint: .topLeading, endPoint: .bottomTrailing))
                                .frame(width: 40, height: 40)
                                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
                            Text("FF")
                                .font(.system(size: 14, weight: .black, design: .rounded))
                                .italic()
                                .foregroundStyle(.white)
                        }
                        
                        Spacer()
                        
                        // Dedicated Grafik MC Icon Button on Card
                        Button {
                            selectedClientForDialog = .standard
                            withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                                showGrafikMCDialog = true
                            }
                        } label: {
                            HStack(spacing: 3) {
                                Image(systemName: "cube.fill")
                                    .font(.system(size: 9))
                                Text("MC")
                                    .font(.system(size: 9, weight: .black, design: .monospaced))
                            }
                            .foregroundStyle(engine.isGrafikMCActive ? AppTheme.emerald : Color.white.opacity(0.7))
                            .padding(.horizontal, 6)
                            .padding(.vertical, 3)
                            .background(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.2) : Color.white.opacity(0.08))
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                            .overlay(RoundedRectangle(cornerRadius: 6).stroke(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.5) : Color.white.opacity(0.15), lineWidth: 1))
                        }
                        .buttonStyle(.plain)

                        Text("STD")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundStyle(Color.white.opacity(0.55))
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.white.opacity(0.06))
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Free Fire")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.white)
                        if engine.isGrafikMCActive {
                            HStack(spacing: 4) {
                                Circle().fill(AppTheme.emerald).frame(width: 4, height: 4)
                                Text("⛏️ \(engine.grafikMCBadgeText)")
                                    .font(.system(size: 8.5, weight: .semibold, design: .monospaced))
                                    .foregroundStyle(AppTheme.emerald)
                                    .lineLimit(1)
                            }
                        } else if engine.is144FPSActive {
                            HStack(spacing: 4) {
                                Circle().fill(AppTheme.emerald).frame(width: 4, height: 4)
                                Text("144 FPS Unlocked")
                                    .font(.system(size: 9, weight: .semibold, design: .monospaced))
                                    .foregroundStyle(AppTheme.emerald)
                            }
                        } else {
                            Text("Original Edition")
                                .font(.system(size: 9))
                                .foregroundStyle(Color.white.opacity(0.5))
                        }
                    }

                    HStack(spacing: 6) {
                        Button {
                            engine.applyTweaksToTarget(bundleID: "com.dts.freefireth", name: "Free Fire", scheme: "freefire")
                        } label: {
                            HStack(spacing: 4) {
                                Text("LAUNCH")
                                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                                    .tracking(1)
                                Image(systemName: "play.fill")
                                    .font(.system(size: 9))
                            }
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 9)
                            .background(Color.white.opacity(0.08))
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.white.opacity(0.12), lineWidth: 1))
                        }
                        .buttonStyle(.plain)

                        // Dialog Trigger Icon Button
                        Button {
                            selectedClientForDialog = .standard
                            withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                                showGrafikMCDialog = true
                            }
                        } label: {
                            Image(systemName: "slider.horizontal.3")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundStyle(engine.isGrafikMCActive ? AppTheme.emerald : Color.white.opacity(0.8))
                                .frame(width: 32, height: 32)
                                .background(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.2) : Color.white.opacity(0.08))
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.4) : Color.white.opacity(0.12), lineWidth: 1))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(12)
                .background(AppTheme.iosCard)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.3) : Color.white.opacity(0.06), lineWidth: 1))

                // 7B. Free Fire MAX Card
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        ZStack {
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .fill(Color.black)
                                .frame(width: 40, height: 40)
                                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(AppTheme.iosRed.opacity(0.6), lineWidth: 1))
                            Text("MAX")
                                .font(.system(size: 13, weight: .black, design: .rounded))
                                .italic()
                                .foregroundStyle(AppTheme.iosRed)
                        }
                        
                        Spacer()
                        
                        // Dedicated Grafik MC Icon Button on MAX Card
                        Button {
                            selectedClientForDialog = .max
                            withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                                showGrafikMCDialog = true
                            }
                        } label: {
                            HStack(spacing: 3) {
                                Image(systemName: "cube.fill")
                                    .font(.system(size: 9))
                                Text("MC")
                                    .font(.system(size: 9, weight: .black, design: .monospaced))
                            }
                            .foregroundStyle(engine.isGrafikMCActive ? AppTheme.emerald : AppTheme.iosRed)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 3)
                            .background(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.2) : AppTheme.iosRedMuted)
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                            .overlay(RoundedRectangle(cornerRadius: 6).stroke(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.5) : AppTheme.iosRed.opacity(0.3), lineWidth: 1))
                        }
                        .buttonStyle(.plain)

                        Text("ULTRA")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundStyle(AppTheme.iosRed)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(AppTheme.iosRedMuted)
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                            .overlay(RoundedRectangle(cornerRadius: 6).stroke(AppTheme.iosRed.opacity(0.3), lineWidth: 1))
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Free Fire MAX")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.white)
                        if engine.isGrafikMCActive {
                            HStack(spacing: 4) {
                                Circle().fill(AppTheme.emerald).frame(width: 4, height: 4)
                                Text("⛏️ \(engine.grafikMCBadgeText)")
                                    .font(.system(size: 8.5, weight: .semibold, design: .monospaced))
                                    .foregroundStyle(AppTheme.emerald)
                                    .lineLimit(1)
                            }
                        } else if engine.is144FPSActive {
                            HStack(spacing: 4) {
                                Circle().fill(AppTheme.iosRed).frame(width: 4, height: 4)
                                Text("144 FPS Ultra Max")
                                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                                    .foregroundStyle(AppTheme.iosRed)
                            }
                        } else {
                            HStack(spacing: 4) {
                                Circle().fill(AppTheme.emerald).frame(width: 4, height: 4)
                                Text("HD Textures")
                                    .font(.system(size: 9, weight: .semibold, design: .monospaced))
                                    .foregroundStyle(AppTheme.emerald)
                            }
                        }
                    }

                    HStack(spacing: 6) {
                        Button {
                            engine.applyTweaksToTarget(bundleID: "com.dts.freefiremax", name: "Free Fire MAX", scheme: "freefiremax")
                        } label: {
                            HStack(spacing: 4) {
                                Text("LAUNCH")
                                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                                    .tracking(1)
                                Image(systemName: "play.fill")
                                    .font(.system(size: 9))
                            }
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 9)
                            .background(
                                LinearGradient(colors: [AppTheme.iosRed, AppTheme.iosRedDark], startPoint: .leading, endPoint: .trailing)
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .shadow(color: AppTheme.iosRed.opacity(0.4), radius: 8, x: 0, y: 2)
                        }
                        .buttonStyle(.plain)

                        // Dialog Trigger Icon Button
                        Button {
                            selectedClientForDialog = .max
                            withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                                showGrafikMCDialog = true
                            }
                        } label: {
                            Image(systemName: "slider.horizontal.3")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundStyle(engine.isGrafikMCActive ? AppTheme.emerald : AppTheme.iosRed)
                                .frame(width: 32, height: 32)
                                .background(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.2) : AppTheme.iosRedMuted)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.4) : AppTheme.iosRed.opacity(0.3), lineWidth: 1))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(12)
                .background(AppTheme.iosCard)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(engine.isGrafikMCActive ? AppTheme.emerald.opacity(0.3) : AppTheme.iosRed.opacity(0.3), lineWidth: 1))
            }
        }
    }

    // MARK: - Dedicated Grafik MC Settings Dialog
    @ViewBuilder
    private func grafikMCDialogView(client: TargetClientType) -> some View {
        VStack(spacing: 16) {
            // Header
            HStack {
                ZStack {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(AppTheme.emerald.opacity(0.18))
                        .frame(width: 36, height: 36)
                        .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(AppTheme.emerald.opacity(0.4), lineWidth: 1))
                    Image(systemName: "cube.fill")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(AppTheme.emerald)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text("PENGATURAN GRAFIK MC")
                        .font(.system(size: 13, weight: .black, design: .monospaced))
                        .foregroundStyle(.white)
                    Text("Target: \(client.displayName)")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundStyle(AppTheme.emerald)
                }

                Spacer()

                Button {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        showGrafikMCDialog = false
                    }
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Color.white.opacity(0.7))
                        .padding(8)
                        .background(Color.white.opacity(0.1))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
            }

            // Switch: Enable Grafik MC
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Aktifkan Mode Grafik MC")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.white)
                    Text("Semua map & lobby flat kotak-kotak ala Minecraft")
                        .font(.system(size: 10))
                        .foregroundStyle(Color.white.opacity(0.55))
                }
                Spacer()
                Toggle("", isOn: $engine.isGrafikMCActive)
                    .labelsHidden()
                    .tint(AppTheme.emerald)
            }
            .padding(12)
            .background(Color.white.opacity(0.04))
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.08), lineWidth: 1))

            // Slider: Tingkat Ke-MC-an / Kotak-Kotak
            VStack(spacing: 8) {
                HStack {
                    Text("Tingkat Kotak-Kotak:")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(.white)
                    Spacer()
                    Text(engine.grafikMCBadgeText)
                        .font(.system(size: 10, weight: .black, design: .monospaced))
                        .foregroundStyle(AppTheme.emerald)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(AppTheme.emerald.opacity(0.18))
                        .clipShape(Capsule())
                }

                Slider(value: $engine.grafikMCLevel, in: 0...4, step: 1)
                    .tint(AppTheme.emerald)

                HStack {
                    Text("0: Normal")
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundStyle(Color.white.opacity(0.4))
                    Spacer()
                    Text("2: Kentang")
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundStyle(Color.white.opacity(0.4))
                    Spacer()
                    Text("3: Kotak MC")
                        .font(.system(size: 9, weight: .bold, design: .monospaced))
                        .foregroundStyle(AppTheme.emerald)
                    Spacer()
                    Text("4: Ultra Flat")
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundStyle(Color.white.opacity(0.4))
                }
            }
            .padding(12)
            .background(Color.white.opacity(0.04))
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.08), lineWidth: 1))

            // Filter Toggle: Nearest vs Linear
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Filter Kotak Tegas (Nearest Pixel)")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(.white)
                    Text("Menghilangkan blur agar tekstur pixelated kotak")
                        .font(.system(size: 10))
                        .foregroundStyle(Color.white.opacity(0.55))
                }
                Spacer()
                Toggle("", isOn: $engine.grafikMCFilterNearest)
                    .labelsHidden()
                    .tint(AppTheme.emerald)
            }
            .padding(12)
            .background(Color.white.opacity(0.04))
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.08), lineWidth: 1))

            // Direct Launch Button
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    showGrafikMCDialog = false
                }
                engine.applyTweaksToTarget(bundleID: client.bundleID, name: client.displayName, scheme: client.scheme)
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "play.fill")
                        .font(.system(size: 11))
                    Text("APPLY & LAUNCH \(client.displayName.uppercased())")
                        .font(.system(size: 12, weight: .black, design: .monospaced))
                        .tracking(1.0)
                }
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(
                    LinearGradient(
                        colors: [AppTheme.emerald, Color(red: 0.05, green: 0.65, blue: 0.42)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .shadow(color: AppTheme.emerald.opacity(0.4), radius: 10, x: 0, y: 3)
            }
            .buttonStyle(.plain)
            .padding(.top, 4)
        }
        .padding(18)
        .background(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Color(red: 16/255, green: 17/255, blue: 22/255).opacity(0.98))
                .overlay(
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .stroke(AppTheme.emerald.opacity(0.5), lineWidth: 1.5)
                )
        )
        .shadow(color: Color.black.opacity(0.85), radius: 30, x: 0, y: 12)
    }

    // MARK: - 8. Join Channel WhatsApp Card
    private var whatsappChannelCard: some View {
        Button {
            if let url = URL(string: "https://whatsapp.com/channel/0029Vb6i1yu9RZAVv3zpDn3w") {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        } label: {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(AppTheme.emerald.opacity(0.12))
                        .frame(width: 40, height: 40)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(AppTheme.emerald.opacity(0.25), lineWidth: 1)
                        )
                    Image(systemName: "message.fill")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(AppTheme.emerald)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text("Join Chanel Whatsaap")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.white)
                    Text("Dapatkan update patch terbaru")
                        .font(.system(size: 10))
                        .foregroundStyle(Color.white.opacity(0.5))
                }

                Spacer()

                Image(systemName: "arrow.up.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Color.white.opacity(0.4))
            }
            .padding(14)
            .background(AppTheme.iosCard)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.white.opacity(0.08), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: - 9. Footer
    private var footerSection: some View {
        HStack(spacing: 4) {
            Text("DEVELOPER BY")
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .tracking(1.4)
                .foregroundStyle(Color.white.opacity(0.45))
            Text("HANX")
                .font(.system(size: 11, weight: .black, design: .monospaced))
                .tracking(1.4)
                .foregroundStyle(AppTheme.iosRed)
        }
        .padding(.top, 8)
    }

    // MARK: - Helper: Hardware Identifier
    private func deviceModelIdentifier() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        return identifier.isEmpty ? "iPhone" : identifier
    }
}
