// ThreeOneOSFive/helpers/LicenseManager.swift
// ACEL SETTINGS IOS — Firebase Realtime License & HWID Lock Manager
// Target: iOS Arm64 Native Client

import Combine
import Foundation
import Security
import UIKit

enum FirebaseConfig {
    static let configuredURL = "https://acel-ios-default-rtdb.asia-southeast1.firebasedatabase.app"

    static var databaseURL: String {
        get {
            if let path = Bundle.main.path(forResource: "GoogleService-Info", ofType: "plist"),
               let dict = NSDictionary(contentsOfFile: path) as? [String: Any],
               let url = dict["DATABASE_URL"] as? String, !url.isEmpty {
                var clean = url.trimmingCharacters(in: .whitespacesAndNewlines)
                if clean.hasSuffix("/") { clean.removeLast() }
                return clean
            }
            let custom = UserDefaults.standard.string(forKey: "acel_firebase_db_url")
            return (custom?.isEmpty == false) ? custom! : configuredURL
        }
        set {
            var clean = newValue.trimmingCharacters(in: .whitespacesAndNewlines)
            if clean.hasSuffix("/") { clean.removeLast() }
            UserDefaults.standard.set(clean, forKey: "acel_firebase_db_url")
        }
    }
}

@MainActor
final class LicenseManager: ObservableObject {
    @Published private(set) var expirationDate: Date?
    @Published private(set) var isActive = false
    @Published private(set) var isBusy = false
    @Published private(set) var message: String?
    @Published private(set) var currentKey: String?
    @Published var rememberKey = true

    private let service = "com.acelios.hanx.activation"
    private let keyAccount = "license-key"
    private let expiryAccount = "license-expiry"
    private var lastAttemptAt: Date?

    var deviceHWID: String {
        UIDevice.current.identifierForVendor?.uuidString ?? "UNKNOWN-HWID"
    }

    init() {
        if let savedKey = rememberedKey(), !savedKey.isEmpty {
            self.currentKey = savedKey
            self.isActive = true
        } else {
            self.isActive = false
        }
    }

    var hasRememberedKey: Bool {
        !(string(for: keyAccount) ?? "").isEmpty
    }

    func rememberedKey() -> String? {
        string(for: keyAccount)
    }

    func beginLaunchSession() {
        if let key = rememberedKey(), !key.isEmpty {
            self.currentKey = key
            self.isActive = true
        }
    }

    func deactivate() {
        delete(keyAccount)
        delete(expiryAccount)
        isActive = false
        currentKey = nil
        message = "Activation removed from this device"
    }

    // MARK: - Firebase Online Verification & HWID Binding
    func activateWithFirebase(key: String, completion: @escaping (Result<String, String>) -> Void) {
        let trimmedKey = key.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !trimmedKey.isEmpty else {
            completion(.failure("Harap masukkan lisensi key!"))
            return
        }

        if let lastAttemptAt, Date().timeIntervalSince(lastAttemptAt) < 1.0 {
            completion(.failure("Tunggu sebentar sebelum mencoba lagi..."))
            return
        }
        lastAttemptAt = Date()
        isBusy = true
        message = "Menghubungi server lisensi…"

        let dbBase = FirebaseConfig.databaseURL
        guard let url = URL(string: "\(dbBase)/keys/\(trimmedKey).json") else {
            isBusy = false
            completion(.failure("URL Server Lisensi tidak valid!"))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 10.0
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                self.isBusy = false

                if let error = error {
                    completion(.failure("Gagal koneksi: \(error.localizedDescription)"))
                    return
                }

                guard let data = data, !data.isEmpty else {
                    completion(.failure("Tidak ada respons dari server."))
                    return
                }

                // Parse response
                guard let json = try? JSONSerialization.jsonObject(with: data, readingOptions: []) as? [String: Any] else {
                    completion(.failure("Key tidak terdaftar di database!"))
                    return
                }

                // 1. Cek Status Ban
                let status = (json["status"] as? String)?.lowercased() ?? "active"
                if status == "banned" {
                    completion(.failure("Key ini telah dinonaktifkan/BANNED oleh admin!"))
                    return
                }

                // 2. Cek Expiry Date jika sudah ada
                let nowMillis = Date().timeIntervalSince1970 * 1000.0
                if let expiresAtMillis = json["expires_at"] as? Double, expiresAtMillis > 0 {
                    if nowMillis > expiresAtMillis {
                        completion(.failure("Masa aktif key ini sudah KADALUARSA!"))
                        return
                    }
                }

                // 3. Cek 1 Key 1 Device (HWID Lock)
                let boundHWID = json["device_id"] as? String
                let myHWID = self.deviceHWID

                if let bound = boundHWID, !bound.isEmpty && bound != myHWID {
                    completion(.failure("Key ini sudah terkunci di iPhone lain! (1 Key 1 Device)"))
                    return
                }

                // 4. Jika baru pertama kali login di device ini, kunci ke HWID ini
                let durationDays = json["duration_days"] as? Int ?? 30
                var newExpiryMillis = json["expires_at"] as? Double

                if boundHWID == nil || boundHWID?.isEmpty == true || newExpiryMillis == nil {
                    // Hitung tanggal kedaluwarsa baru
                    if durationDays >= 9000 {
                        newExpiryMillis = 0 // Lifetime
                    } else {
                        newExpiryMillis = nowMillis + Double(durationDays * 24 * 3600 * 1000)
                    }

                    self.bindDeviceToFirebase(key: trimmedKey, hwid: myHWID, expiryMillis: newExpiryMillis)
                }

                // Simpan aktivasi ke Keychain lokal
                if self.rememberKey {
                    self.save(trimmedKey, for: self.keyAccount)
                }
                self.currentKey = trimmedKey
                self.isActive = true
                self.message = "Aktivasi Berhasil! VIP Aktif"
                completion(.success("Akses Diterima! Selamat Datang VIP"))
            }
        }.resume()
    }

    private func bindDeviceToFirebase(key: String, hwid: String, expiryMillis: Double?) {
        guard let url = URL(string: "\(FirebaseConfig.databaseURL)/keys/\(key).json") else { return }

        var payload: [String: Any] = [
            "device_id": hwid,
            "device_model": AppInfo.displayMachineName,
            "ios_version": AppInfo.osVersion,
            "activated_at": Date().timeIntervalSince1970 * 1000.0
        ]
        if let exp = expiryMillis, exp > 0 {
            payload["expires_at"] = exp
        }

        guard let httpBody = try? JSONSerialization.data(withJSONObject: payload, options: []) else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "PATCH"
        request.httpBody = httpBody
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request).resume()
    }

    // MARK: - Keychain Storage
    private func string(for account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func save(_ value: String, for account: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        var item = base
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }

    private func delete(_ account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}
