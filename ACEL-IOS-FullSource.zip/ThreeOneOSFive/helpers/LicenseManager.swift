// ThreeOneOSFive/helpers/LicenseManager.swift
// ACEL SETTINGS IOS — Firebase Realtime License & HWID Lock Manager
// Target: iOS Arm64 Native Client

import Combine
import Foundation
import Security
import UIKit

enum FirebaseConfig {
    static let configuredURL = "https://acel-ios-default-rtdb.asia-southeast1.firebasedatabase.app"

    static var databaseURL: String {
        get {
            if let path = Bundle.main.path(forResource: "GoogleService-Info", ofType: "plist"),
               let dict = NSDictionary(contentsOfFile: path) as? [String: Any],
               let url = dict["DATABASE_URL"] as? String, !url.isEmpty {
                var clean = url.trimmingCharacters(in: .whitespacesAndNewlines)
                if clean.hasSuffix("/") { clean.removeLast() }
                return clean
            }
            let custom = UserDefaults.standard.string(forKey: "acel_firebase_db_url")
            return (custom?.isEmpty == false) ? custom! : configuredURL
        }
        set {
            var clean = newValue.trimmingCharacters(in: .whitespacesAndNewlines)
            if clean.hasSuffix("/") { clean.removeLast() }
            UserDefaults.standard.set(clean, forKey: "acel_firebase_db_url")
        }
    }
}

@MainActor
final class LicenseManager: ObservableObject {
    @Published private(set) var expirationDate: Date?
    @Published private(set) var isActive = false
    @Published private(set) var isBusy = false
    @Published private(set) var message: String?
    @Published private(set) var currentKey: String?
    @Published var rememberKey = true

    private let service = "com.acelios.hanx.activation"
    private let keyAccount = "license-key"
    private let expiryAccount = "license-expiry"
    private var lastAttemptAt: Date?
    private var expiryCheckTimer: Timer?

    var deviceHWID: String {
        UIDevice.current.identifierForVendor?.uuidString ?? "UNKNOWN-HWID"
    }

    init() {
        if let savedKey = rememberedKey(), !savedKey.isEmpty {
            self.currentKey = savedKey
            if isLocalKeyExpired() {
                self.isActive = false
                delete(keyAccount)
                delete(expiryAccount)
            } else {
                self.isActive = true
                startLiveExpiryMonitor()
            }
        } else {
            self.isActive = false
        }
    }

    var hasRememberedKey: Bool {
        !(string(for: keyAccount) ?? "").isEmpty
    }

    func rememberedKey() -> String? {
        string(for: keyAccount)
    }

    func isLocalKeyExpired() -> Bool {
        guard let expStr = string(for: expiryAccount),
              let expMillis = Double(expStr), expMillis > 0 else {
            return false
        }
        let nowMillis = Date().timeIntervalSince1970 * 1000.0
        return nowMillis > expMillis
    }

    func beginLaunchSession() {
        guard let key = rememberedKey(), !key.isEmpty else {
            self.isActive = false
            return
        }
        self.currentKey = key

        if isLocalKeyExpired() {
            handleExpiredKey(reason: "Masa aktif lisensi telah habis!")
            return
        }

        self.isActive = true
        startLiveExpiryMonitor()
        validateWithFirebaseSilent(key: key)
    }

    func startLiveExpiryMonitor() {
        expiryCheckTimer?.invalidate()
        expiryCheckTimer = Timer.scheduledTimer(withTimeInterval: 60.0, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self = self, self.isActive, let key = self.currentKey else { return }
                if self.isLocalKeyExpired() {
                    self.handleExpiredKey(reason: "Masa aktif lisensi telah habis!")
                    return
                }
                self.validateWithFirebaseSilent(key: key)
            }
        }
    }

    func handleExpiredKey(reason: String) {
        expiryCheckTimer?.invalidate()
        expiryCheckTimer = nil
        deactivate()
        message = reason
        AcelTuningEngine.shared.showToast(reason, isError: true)
    }

    func validateWithFirebaseSilent(key: String) {
        let dbBase = FirebaseConfig.databaseURL
        guard let url = URL(string: "\(dbBase)/keys/\(key).json") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 8.0

        URLSession.shared.dataTask(with: request) { [weak self] data, _, error in
            guard let data = data, error == nil,
                  let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
                return
            }

            Task { @MainActor [weak self] in
                guard let self = self, self.isActive else { return }

                let status = (json["status"] as? String)?.lowercased() ?? "active"
                if status == "banned" {
                    self.handleExpiredKey(reason: "Lisensi dinonaktifkan oleh Admin!")
                    return
                }

                let boundHWID = json["device_id"] as? String
                if let bound = boundHWID, !bound.isEmpty && bound != self.deviceHWID {
                    self.handleExpiredKey(reason: "Lisensi dipindah ke perangkat lain!")
                    return
                }

                let nowMillis = Date().timeIntervalSince1970 * 1000.0
                if let exp = json["expires_at"] as? Double, exp > 0 {
                    self.save(String(Int64(exp)), for: self.expiryAccount)
                    if nowMillis > exp {
                        self.handleExpiredKey(reason: "Masa aktif lisensi telah kedaluwarsa!")
                        return
                    }
                }
            }
        }.resume()
    }

    func deactivate() {
        expiryCheckTimer?.invalidate()
        expiryCheckTimer = nil
        delete(keyAccount)
        delete(expiryAccount)
        isActive = false
        currentKey = nil
        message = "Activation removed from this device"
    }

    // MARK: - Firebase Online Verification & HWID Binding
    func activateWithFirebase(key: String, completion: @escaping (Bool, String) -> Void) {
        let trimmedKey = key.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !trimmedKey.isEmpty else {
            completion(false, "Harap masukkan lisensi key!")
            return
        }

        if let lastAttemptAt, Date().timeIntervalSince(lastAttemptAt) < 1.0 {
            completion(false, "Tunggu sebentar sebelum mencoba lagi...")
            return
        }
        lastAttemptAt = Date()
        isBusy = true
        message = "Menghubungi server lisensi…"

        let dbBase = FirebaseConfig.databaseURL
        guard let url = URL(string: "\(dbBase)/keys/\(trimmedKey).json") else {
            isBusy = false
            completion(false, "URL Server Lisensi tidak valid!")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 10.0
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                self.isBusy = false

                if let error = error {
                    completion(false, "Gagal koneksi: \(error.localizedDescription)")
                    return
                }

                guard let data = data, !data.isEmpty else {
                    completion(false, "Tidak ada respons dari server.")
                    return
                }

                // Parse response
                guard let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
                    completion(false, "Key tidak terdaftar di database!")
                    return
                }

                // 1. Cek Status Ban
                let status = (json["status"] as? String)?.lowercased() ?? "active"
                if status == "banned" {
                    completion(false, "Key ini telah dinonaktifkan/BANNED oleh admin!")
                    return
                }

                // 2. Cek Expiry Date jika sudah ada
                let nowMillis = Date().timeIntervalSince1970 * 1000.0
                if let expiresAtMillis = json["expires_at"] as? Double, expiresAtMillis > 0 {
                    if nowMillis > expiresAtMillis {
                        completion(false, "Masa aktif key ini sudah KADALUARSA!")
                        return
                    }
                }

                // 3. Cek 1 Key 1 Device (HWID Lock)
                let boundHWID = json["device_id"] as? String
                let myHWID = self.deviceHWID

                if let bound = boundHWID, !bound.isEmpty && bound != myHWID {
                    completion(false, "Key ini sudah terkunci di iPhone lain! (1 Key 1 Device)")
                    return
                }

                // 4. Jika baru pertama kali login di device ini, kunci ke HWID ini
                let durationDays = json["duration_days"] as? Int ?? 30
                var newExpiryMillis = json["expires_at"] as? Double

                if boundHWID == nil || boundHWID?.isEmpty == true || newExpiryMillis == nil {
                    // Hitung tanggal kedaluwarsa baru
                    if durationDays >= 9000 {
                        newExpiryMillis = 0 // Lifetime
                    } else {
                        newExpiryMillis = nowMillis + Double(durationDays * 24 * 3600 * 1000)
                    }

                    self.bindDeviceToFirebase(key: trimmedKey, hwid: myHWID, expiryMillis: newExpiryMillis)
                }

                // Simpan aktivasi ke Keychain lokal
                if self.rememberKey {
                    self.save(trimmedKey, for: self.keyAccount)
                    if let exp = newExpiryMillis {
                        self.save(String(Int64(exp)), for: self.expiryAccount)
                    }
                }
                self.currentKey = trimmedKey
                self.isActive = true
                self.startLiveExpiryMonitor()
                self.message = "Aktivasi Berhasil! VIP Aktif"
                completion(true, "Akses Diterima! Selamat Datang VIP")
            }
        }.resume()
    }

    private func bindDeviceToFirebase(key: String, hwid: String, expiryMillis: Double?) {
        guard let url = URL(string: "\(FirebaseConfig.databaseURL)/keys/\(key).json") else { return }

        var payload: [String: Any] = [
            "device_id": hwid,
            "device_model": AppInfo.displayMachineName,
            "ios_version": AppInfo.osVersion,
            "activated_at": Date().timeIntervalSince1970 * 1000.0
        ]
        if let exp = expiryMillis, exp > 0 {
            payload["expires_at"] = exp
        }

        guard let httpBody = try? JSONSerialization.data(withJSONObject: payload, options: []) else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "PATCH"
        request.httpBody = httpBody
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request).resume()
    }

    // MARK: - Keychain Storage
    private func string(for account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func save(_ value: String, for account: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        var item = base
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }

    private func delete(_ account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}
