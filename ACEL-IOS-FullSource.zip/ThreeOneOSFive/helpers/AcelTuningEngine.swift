// ThreeOneOSFive/helpers/AcelTuningEngine.swift
// ACEL SETTINGS IOS — Kinetic Touch Tracking & Drag Calibration Engine
// Target: iOS Free Fire & Free Fire MAX

import Foundation
import UIKit
import Combine
import Darwin

@MainActor
final class AcelTuningEngine: ObservableObject {
    static let shared = AcelTuningEngine()

    private enum Keys {
        static let optimizeActive = "acel_optimize_ios_active"
        static let trackingValue = "acel_tracking_value"
        static let dragValue = "acel_drag_slickness_value"
    }

    @Published var isOptimizeActive: Bool {
        didSet {
            UserDefaults.standard.set(isOptimizeActive, forKey: Keys.optimizeActive)
            if isOptimizeActive {
                runMemoryOptimization()
                showToast("Optimize iOS: Active", isError: false)
            } else {
                showToast("Optimize iOS: Standby", isError: false)
            }
        }
    }

    @Published var trackingValue: Double {
        didSet {
            UserDefaults.standard.set(trackingValue, forKey: Keys.trackingValue)
        }
    }

    @Published var dragValue: Double {
        didSet {
            UserDefaults.standard.set(dragValue, forKey: Keys.dragValue)
        }
    }

    // Dynamic Island Toast State
    @Published var toastMessage: String?
    @Published var toastIsError: Bool = false
    @Published var showToast: Bool = false
    private var toastWorkItem: DispatchWorkItem?

    private init() {
        let savedOptimize = UserDefaults.standard.object(forKey: Keys.optimizeActive) as? Bool ?? true
        let savedTracking = UserDefaults.standard.object(forKey: Keys.trackingValue) as? Double ?? 85.0
        let savedDrag = UserDefaults.standard.object(forKey: Keys.dragValue) as? Double ?? 92.0

        self.isOptimizeActive = savedOptimize
        self.trackingValue = savedTracking
        self.dragValue = savedDrag

        if savedOptimize {
            runMemoryOptimization()
        }
    }

    // Tracking Level String Readout
    var trackingBadgeText: String {
        let val = Int(trackingValue)
        let level: String
        if val > 80 {
            level = "Extreme"
        } else if val > 60 {
            level = "High"
        } else if val > 30 {
            level = "Mid"
        } else {
            level = "Low"
        }
        return "Level: \(level) (\(val)%)"
    }

    // Drag Kelicinan Badge Text
    var dragBadgeText: String {
        let val = Int(dragValue)
        let mult = String(format: "%.1fx", dragVelocityMultiplier)
        let level: String
        if val >= 95 {
            level = "Godly Slick"
        } else if val >= 80 {
            level = "Ultra Extreme"
        } else if val >= 50 {
            level = "Super Smooth"
        } else {
            level = "Smooth (Max Kemarin)"
        }
        return "\(level) (\(val)% - \(mult))"
    }

    // Drag Velocity Multiplier (Kalibrasi Kemarin yang Diboost: 20% = 4.5x, 100% = 9.5x)
    var dragVelocityMultiplier: Double {
        return 3.25 + (dragValue / 100.0) * 6.25
    }

    func showToast(_ message: String, isError: Bool = false) {
        toastWorkItem?.cancel()
        toastMessage = message
        toastIsError = isError
        showToast = true

        let item = DispatchWorkItem { [weak self] in
            self?.showToast = false
        }
        toastWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute: item)
    }

    func runMemoryOptimization() {
        URLCache.shared.removeAllCachedResponses()
        NotificationCenter.default.post(
            name: UIApplication.didReceiveMemoryWarningNotification,
            object: nil
        )
    }

    // Inject & Apply Sensitivity Multipliers directly into game preferences
    func applyTweaksToTarget(bundleID: String, name: String, scheme: String) {
        if isOptimizeActive {
            runMemoryOptimization()
        }

        // Try writing tuning configs into game sandbox container if accessible
        if let containerPath = ContainerStore.resolveAppContainerPath(bundleID: bundleID) {
            let prefsURL = URL(fileURLWithPath: containerPath)
                .appendingPathComponent("Library/Preferences", isDirectory: true)
                .appendingPathComponent("\(bundleID).plist")

            var dict: [String: Any] = (NSDictionary(contentsOf: prefsURL) as? [String: Any]) ?? [:]
            dict["AcelTouchMultiplier"] = dragVelocityMultiplier
            dict["AcelTrackingGain"] = trackingValue / 100.0
            dict["AcelKernelBoost"] = isOptimizeActive
            dict["AcelLastTuned"] = Date().timeIntervalSince1970

            let nsDict = NSDictionary(dictionary: dict)
            try? nsDict.write(to: prefsURL)
        }

        showToast("Tweak \(name) Aktif! Kelicinan \(dragBadgeText)", isError: false)

        // Launch Game
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            self?.launchGame(name: name, scheme: scheme)
        }
    }

    func launchGame(name: String, scheme: String) {
        guard let url = URL(string: "\(scheme)://") else { return }
        
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            // If scheme cannot be opened directly, launch via universal link or notify
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
                self?.showToast("Buka game \(name) di iPhone Anda untuk bermain!", isError: false)
            }
        }
    }
}
