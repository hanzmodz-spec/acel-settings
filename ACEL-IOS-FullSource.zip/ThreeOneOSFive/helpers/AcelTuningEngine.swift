// ThreeOneOSFive/helpers/AcelTuningEngine.swift
// ACEL SETTINGS IOS — Kinetic Touch Tracking, 144 FPS & Grafik MC Potato Engine
// Target: iOS Free Fire & Free Fire MAX

import Foundation
import UIKit
import Combine
import Darwin

@MainActor
final class AcelTuningEngine: ObservableObject {
    static let shared = AcelTuningEngine()

    private enum Keys {
        static let optimizeActive = "acel_optimize_ios_active"
        static let trackingValue = "acel_tracking_value"
        static let dragValue = "acel_drag_slickness_value"
        static let fps144Active = "acel_fps144_active"
        static let grafikMCActive = "acel_grafik_mc_active"
        static let grafikMCLevel = "acel_grafik_mc_level"
        static let grafikMCFilterNearest = "acel_grafik_mc_filter_nearest"
    }

    @Published var isOptimizeActive: Bool {
        didSet {
            UserDefaults.standard.set(isOptimizeActive, forKey: Keys.optimizeActive)
            if isOptimizeActive {
                runMemoryOptimization()
                showToast("Optimize iOS: Active", isError: false)
            } else {
                showToast("Optimize iOS: Standby", isError: false)
            }
        }
    }

    @Published var is144FPSActive: Bool {
        didSet {
            UserDefaults.standard.set(is144FPSActive, forKey: Keys.fps144Active)
            if is144FPSActive {
                showToast("Unlock 144 FPS: ACTIVE", isError: false)
            } else {
                showToast("Unlock 144 FPS: STANDBY", isError: false)
            }
        }
    }

    @Published var isGrafikMCActive: Bool {
        didSet {
            UserDefaults.standard.set(isGrafikMCActive, forKey: Keys.grafikMCActive)
            if isGrafikMCActive {
                showToast("Grafik MC: AKTIF (\(grafikMCBadgeText))", isError: false)
            } else {
                showToast("Grafik MC: NONAKTIF (HD Standard)", isError: false)
            }
        }
    }

    @Published var grafikMCLevel: Double {
        didSet {
            UserDefaults.standard.set(grafikMCLevel, forKey: Keys.grafikMCLevel)
        }
    }

    @Published var grafikMCFilterNearest: Bool {
        didSet {
            UserDefaults.standard.set(grafikMCFilterNearest, forKey: Keys.grafikMCFilterNearest)
        }
    }

    @Published var trackingValue: Double {
        didSet {
            UserDefaults.standard.set(trackingValue, forKey: Keys.trackingValue)
        }
    }

    @Published var dragValue: Double {
        didSet {
            UserDefaults.standard.set(dragValue, forKey: Keys.dragValue)
        }
    }

    // Dynamic Island Toast State
    @Published var toastMessage: String?
    @Published var toastIsError: Bool = false
    @Published var showToast: Bool = false
    private var toastWorkItem: DispatchWorkItem?

    private init() {
        let savedOptimize = UserDefaults.standard.object(forKey: Keys.optimizeActive) as? Bool ?? true
        let saved144 = UserDefaults.standard.object(forKey: Keys.fps144Active) as? Bool ?? true
        let savedMC = UserDefaults.standard.object(forKey: Keys.grafikMCActive) as? Bool ?? true
        let savedMCLevel = UserDefaults.standard.object(forKey: Keys.grafikMCLevel) as? Double ?? 3.0
        let savedMCFilter = UserDefaults.standard.object(forKey: Keys.grafikMCFilterNearest) as? Bool ?? true
        let savedTracking = UserDefaults.standard.object(forKey: Keys.trackingValue) as? Double ?? 35.0
        let savedDrag = UserDefaults.standard.object(forKey: Keys.dragValue) as? Double ?? 95.0

        self.isOptimizeActive = savedOptimize
        self.is144FPSActive = saved144
        self.isGrafikMCActive = savedMC
        self.grafikMCLevel = savedMCLevel
        self.grafikMCFilterNearest = savedMCFilter
        self.trackingValue = savedTracking
        self.dragValue = savedDrag

        if savedOptimize {
            runMemoryOptimization()
        }
    }

    // Tracking Level String Readout (Anti-Body Lock Calibration)
    var trackingBadgeText: String {
        let val = Int(trackingValue)
        let level: String
        if val <= 45 {
            level = "Headshot Lift (Anti-Lock)"
        } else if val <= 70 {
            level = "Balanced Tracking"
        } else {
            level = "Tight Body Lock"
        }
        return "\(level) (\(val)%)"
    }

    // Drag Kelicinan Badge Text
    var dragBadgeText: String {
        let val = Int(dragValue)
        let mult = String(format: "%.1fx", dragVelocityMultiplier)
        let level: String
        if val >= 90 {
            level = "Gacor Super Slick"
        } else if val >= 70 {
            level = "Hyper Smooth"
        } else {
            level = "Smooth Boost"
        }
        return "\(level) (\(val)% - \(mult))"
    }

    // Grafik MC / Potato Badge Text
    var grafikMCBadgeText: String {
        let val = Int(grafikMCLevel)
        switch val {
        case 0: return "Normal (HD)"
        case 1: return "Half Res (50%)"
        case 2: return "Kentang (25%)"
        case 3: return "Kotak MC (Rekomendasi)"
        case 4: return "Ultra Burik MC (100% Flat)"
        default: return "Kotak Level \(val)"
        }
    }

    // Drag Velocity Multiplier (Responsif & Licin Gacor: 4.0x hingga 12.0x)
    var dragVelocityMultiplier: Double {
        return 4.0 + (dragValue / 100.0) * 8.0
    }

    func showToast(_ message: String, isError: Bool = false) {
        toastWorkItem?.cancel()
        toastMessage = message
        toastIsError = isError
        showToast = true

        let item = DispatchWorkItem { [weak self] in
            self?.showToast = false
        }
        toastWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute: item)
    }

    func runMemoryOptimization() {
        URLCache.shared.removeAllCachedResponses()
        NotificationCenter.default.post(
            name: UIApplication.didReceiveMemoryWarningNotification,
            object: nil
        )
    }

    // Inject & Apply Sensitivity Multipliers directly into game preferences
    func applyTweaksToTarget(bundleID: String, name: String, scheme: String) {
        if isOptimizeActive {
            runMemoryOptimization()
        }

        // Try writing tuning configs into game sandbox container if accessible
        if let containerPath = ContainerStore.resolveAppContainerPath(bundleID: bundleID) {
            let prefsURL = URL(fileURLWithPath: containerPath)
                .appendingPathComponent("Library/Preferences", isDirectory: true)
                .appendingPathComponent("\(bundleID).plist")

            var dict: [String: Any] = (NSDictionary(contentsOf: prefsURL) as? [String: Any]) ?? [:]
            dict["AcelTouchMultiplier"] = dragVelocityMultiplier
            dict["AcelTrackingGain"] = trackingValue / 100.0
            dict["AcelKernelBoost"] = isOptimizeActive
            dict["AcelVerticalLiftRatio"] = 1.65
            dict["AcelAntiBodyLock"] = true
            dict["AcelLastTuned"] = Date().timeIntervalSince1970

            // Real Free Fire iOS Preference Keys (Extracted from official com.dts.freefireth.plist)
            // In Free Fire: 2.0 = 200 Max In-Game Sensitivity. We scale up to 4.5x - 6.0x for Hyper Slickness.
            let sensVal = max(2.5, min(6.0, dragVelocityMultiplier / 2.0))
            
            dict["Sensitivity"] = sensVal
            dict["Sensitivity_preset_0"] = sensVal
            dict["Sensitivity_preset_1"] = sensVal
            
            dict["ScopeSensitivity_1"] = sensVal
            dict["ScopeSensitivity_1_preset_0"] = sensVal
            dict["ScopeSensitivity_1_preset_1"] = sensVal
            
            dict["ScopeSensitivity_2"] = sensVal
            dict["ScopeSensitivity_2_preset_0"] = sensVal
            dict["ScopeSensitivity_2_preset_1"] = sensVal
            
            dict["ScopeSensitivity_4"] = sensVal
            dict["ScopeSensitivity_4_preset_0"] = sensVal
            dict["ScopeSensitivity_4_preset_1"] = sensVal
            
            dict["ScopeSensitivity_8"] = sensVal
            dict["ScopeSensitivity_8_preset_0"] = sensVal
            dict["ScopeSensitivity_8_preset_1"] = sensVal
            
            dict["AuxAimSensitivity"] = sensVal
            dict["AuxAimSensitivity_preset_0"] = sensVal
            dict["AuxAimSensitivity_preset_1"] = sensVal
            
            // 144 FPS Ultra Switch Logic
            if is144FPSActive {
                dict["HighFPS"] = 4
                dict["SmoothHighFrame"] = 1
                dict["EnableCompatibleGraphicsDeviceName"] = 1
                dict["ReduceResolution"] = 1
                dict["CADisplayLinkPreferredFPS"] = 120
                dict["TargetFPS"] = 144
                dict["ScreenTouchRate"] = 120.0
                dict["TouchSamplingRate"] = 120.0
                dict["Acel144FPSActive"] = true
            } else {
                dict["Acel144FPSActive"] = false
            }

            // Grafik MC / Potato Graphics Engine Logic
            if isGrafikMCActive {
                let mcLvl = Int(grafikMCLevel)
                dict["GrafikMCActive"] = true
                dict["GrafikMCLevel"] = mcLvl
                dict["masterTextureLimit"] = mcLvl
                dict["QualitySettings_masterTextureLimit"] = mcLvl
                dict["ReduceResolution"] = 1
                dict["Quality"] = 0
                dict["SmoothHighFrame"] = 1
                dict["Shadow"] = 0
                dict["HighRes"] = 0
                dict["TextureQuality"] = 0
                dict["FilterMode"] = grafikMCFilterNearest ? 0 : 1
                dict["LODBias"] = 2.0 + (Double(mcLvl) * 2.5)
                dict["MipMapBias"] = 2.0 + (Double(mcLvl) * 2.5)
            } else {
                dict["GrafikMCActive"] = false
                dict["masterTextureLimit"] = 0
            }

            dict["AimAssist"] = 0
            dict["UseAuxAimNew"] = 0

            let nsDict = NSDictionary(dictionary: dict)
            try? nsDict.write(to: prefsURL)
        }

        let mcLabel = isGrafikMCActive ? " [⛏️ \(grafikMCBadgeText)]" : ""
        let fpsLabel = is144FPSActive ? " (144 FPS)" : ""
        showToast("Tweak \(name) Aktif!\(fpsLabel)\(mcLabel)", isError: false)

        // Launch Game
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            self?.launchGame(name: name, scheme: scheme)
        }
    }

    func launchGame(name: String, scheme: String) {
        guard let url = URL(string: "\(scheme)://") else { return }
        
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            // If scheme cannot be opened directly, launch via universal link or notify
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
                self?.showToast("Buka game \(name) di iPhone Anda untuk bermain!", isError: false)
            }
        }
    }
}
