// ThreeOneOSFive/helpers/AcelTuningEngine.swift
// ACEL SETTINGS IOS — Kinetic Touch Tracking & Drag Calibration Engine
// Target: iOS Free Fire & Free Fire MAX

import Foundation
import UIKit
import Combine
import Darwin

@MainActor
final class AcelTuningEngine: ObservableObject {
    static let shared = AcelTuningEngine()

    private enum Keys {
        static let optimizeActive = "acel_optimize_ios_active"
        static let trackingValue = "acel_tracking_value"
        static let dragValue = "acel_drag_slickness_value"
    }

    @Published var isOptimizeActive: Bool {
        didSet {
            UserDefaults.standard.set(isOptimizeActive, forKey: Keys.optimizeActive)
            if isOptimizeActive {
                runMemoryOptimization()
                showToast("Optimize iOS: Active", isError: false)
            } else {
                showToast("Optimize iOS: Standby", isError: false)
            }
        }
    }

    @Published var trackingValue: Double {
        didSet {
            UserDefaults.standard.set(trackingValue, forKey: Keys.trackingValue)
        }
    }

    @Published var dragValue: Double {
        didSet {
            UserDefaults.standard.set(dragValue, forKey: Keys.dragValue)
        }
    }

    // Dynamic Island Toast State
    @Published var toastMessage: String?
    @Published var toastIsError: Bool = false
    @Published var showToast: Bool = false
    private var toastWorkItem: DispatchWorkItem?

    private init() {
        let savedOptimize = UserDefaults.standard.object(forKey: Keys.optimizeActive) as? Bool ?? true
        let savedTracking = UserDefaults.standard.object(forKey: Keys.trackingValue) as? Double ?? 85.0
        let savedDrag = UserDefaults.standard.object(forKey: Keys.dragValue) as? Double ?? 92.0

        self.isOptimizeActive = savedOptimize
        self.trackingValue = savedTracking
        self.dragValue = savedDrag

        if savedOptimize {
            runMemoryOptimization()
        }
    }

    // Tracking Level String Readout
    var trackingBadgeText: String {
        let val = Int(trackingValue)
        let level: String
        if val > 80 {
            level = "Extreme"
        } else if val > 60 {
            level = "High"
        } else if val > 30 {
            level = "Mid"
        } else {
            level = "Low"
        }
        return "Level: \(level) (\(val)%)"
    }

    // Drag Kelicinan Badge Text
    var dragBadgeText: String {
        let val = Int(dragValue)
        let mult = String(format: "%.1fx", dragVelocityMultiplier)
        let level: String
        if val >= 95 {
            level = "Godly Hyper Slick"
        } else if val >= 85 {
            level = "Ultra Extreme"
        } else if val >= 70 {
            level = "Super Slick"
        } else if val >= 50 {
            level = "Hyper Smooth"
        } else {
            level = "Smooth Boost"
        }
        return "\(level) (\(val)% | \(mult))"
    }

    // Drag Velocity Multiplier (Aggressive Non-Linear Curve up to 25.0x)
    // Exponent 0.75 ensures 70%-90% ramp up immediately, giving super licin response even if game sensi is 0.
    var dragVelocityMultiplier: Double {
        let normalized = max(0.0, min(1.0, dragValue / 100.0))
        return 3.0 + pow(normalized, 0.75) * 22.0
    }

    func showToast(_ message: String, isError: Bool = false) {
        toastWorkItem?.cancel()
        toastMessage = message
        toastIsError = isError
        showToast = true

        let item = DispatchWorkItem { [weak self] in
            self?.showToast = false
        }
        toastWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute: item)
    }

    func runMemoryOptimization() {
        URLCache.shared.removeAllCachedResponses()
        NotificationCenter.default.post(
            name: UIApplication.didReceiveMemoryWarningNotification,
            object: nil
        )
    }

    // Inject & Apply Sensitivity Multipliers directly into game preferences & container
    func applyTweaksToTarget(bundleID: String, name: String, scheme: String) {
        // Haptic feedback on physical device
        let feedback = UIImpactFeedbackGenerator(style: .heavy)
        feedback.prepare()
        feedback.impactOccurred()

        if isOptimizeActive {
            runMemoryOptimization()
        }

        // 1. Auto-apply bundled patch packages if available for this bundleID
        applyMatchingBundledPatches(bundleID: bundleID)

        // 2. Inject comprehensive sensitivity, friction reduction, & touch multipliers
        if let containerPath = ContainerStore.resolveAppContainerPath(bundleID: bundleID) {
            let prefsDir = URL(fileURLWithPath: containerPath).appendingPathComponent("Library/Preferences", isDirectory: true)
            try? FileManager.default.createDirectory(at: prefsDir, withIntermediateDirectories: true)

            let targetURLs = [
                prefsDir.appendingPathComponent("\(bundleID).plist"),
                prefsDir.appendingPathComponent("UnityPlayer.plist"),
                prefsDir.appendingPathComponent("com.unity.player.plist")
            ]

            let mult = dragVelocityMultiplier
            let trackingGain = (trackingValue / 100.0) * 3.5

            for targetURL in targetURLs {
                var dict: [String: Any] = (NSDictionary(contentsOf: targetURL) as? [String: Any]) ?? [:]
                dict["AcelTouchMultiplier"] = mult
                dict["AcelTrackingGain"] = trackingGain
                dict["AcelKernelBoost"] = isOptimizeActive
                dict["AcelSuperSlickActive"] = true
                dict["AcelSensitivityBoost"] = mult
                dict["AcelLastTuned"] = Date().timeIntervalSince1970

                // Deep Unity & Darwin touch calibration parameters
                dict["TouchMultiplier"] = mult
                dict["TouchDragVelocity"] = mult * 1.5
                dict["TouchFrictionReduction"] = 1.0
                dict["TouchTrackingGain"] = trackingGain
                dict["TouchScale"] = mult
                dict["TouchSensitivity"] = mult * 1.2
                dict["GeneralSensitivity"] = 100.0 + (mult * 10.0)
                dict["UnityPlayer.Sensitivity"] = mult
                dict["ScreenTouchRate"] = 120.0
                dict["TouchResponseSpeed"] = 0.001
                dict["CameraSensitivity"] = 200.0 * (mult / 8.0)
                dict["RedDotSensitivity"] = 200.0 * (mult / 8.0)
                dict["Scope2xSensitivity"] = 200.0 * (mult / 8.0)
                dict["Scope4xSensitivity"] = 200.0 * (mult / 8.0)
                dict["AWM_Sensitivity"] = 200.0 * (mult / 8.0)
                dict["FreeLookSensitivity"] = 200.0 * (mult / 8.0)
                dict["DragFriction"] = 0.0
                dict["TouchInterpolation"] = false
                dict["TouchAcceleration"] = mult * 2.0

                let nsDict = NSDictionary(dictionary: dict)
                try? nsDict.write(to: targetURL)
            }
        }

        showToast("Tweak \(name) Aktif! (\(dragBadgeText))", isError: false)

        // Launch Game
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            self?.launchGame(name: name, scheme: scheme)
        }
    }

    private func applyMatchingBundledPatches(bundleID: String) {
        PatchProjectLibrary.installBundledPackagesIfNeeded()
        let items = PatchProjectLibrary.load()
        for item in items {
            guard let project = item.project else { continue }
            if project.allBundleIdentifiers.contains(bundleID) {
                _ = try? DevicePatchService.apply(project: project)
            }
        }
    }

    func launchGame(name: String, scheme: String) {
        guard let url = URL(string: "\(scheme)://") else { return }
        
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            // If scheme cannot be opened directly, launch via universal link or notify
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
                self?.showToast("Buka game \(name) di iPhone Anda untuk bermain!", isError: false)
            }
        }
    }
}
