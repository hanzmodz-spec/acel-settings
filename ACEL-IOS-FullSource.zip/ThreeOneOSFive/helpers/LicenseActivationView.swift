// ThreeOneOSFive/helpers/LicenseActivationView.swift
// ACEL IOS — Screen 1: Login Key Screen
// 1:1 Accurate Replication of HTML Cyberpunk Design

import SwiftUI

struct LicenseActivationView: View {
    @ObservedObject var manager: LicenseManager
    @ObservedObject private var engine = AcelTuningEngine.shared
    @State private var key = ""
    @FocusState private var keyFocused: Bool
    @State private var shakeOffset: CGFloat = 0

    var body: some View {
        ZStack {
            // Background #08080A
            AppTheme.iosDark
                .ignoresSafeArea()

            VStack(spacing: 0) {
                // Top iOS Status Bar spacing
                Spacer(minLength: 20)

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        // MARK: - Logo & Brand Header
                        VStack(spacing: 12) {
                            ZStack(alignment: .topTrailing) {
                                RoundedRectangle(cornerRadius: 24, style: .continuous)
                                    .fill(
                                        LinearGradient(
                                            colors: [Color(red: 32/255, green: 16/255, blue: 21/255), Color(red: 14/255, green: 11/255, blue: 16/255)],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        )
                                    )
                                    .frame(width: 84, height: 84)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                                            .stroke(AppTheme.iosRed.opacity(0.4), lineWidth: 1.5)
                                    )
                                    .shadow(color: AppTheme.iosRed.opacity(0.35), radius: 18, x: 0, y: 0)

                                // Angel Logo Image
                                Image("AcelLogo")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 80, height: 80)
                                    .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))

                                // Pulsing Red Dot on Corner
                                Circle()
                                    .fill(AppTheme.iosRed)
                                    .frame(width: 10, height: 10)
                                    .offset(x: 2, y: -2)
                                    .shadow(color: AppTheme.iosRed, radius: 4)
                            }
                            .padding(.top, 16)

                            VStack(spacing: 4) {
                                Text("ACEL IOS")
                                    .font(.system(size: 28, weight: .black, design: .rounded))
                                    .tracking(3)
                                    .foregroundStyle(.white)

                                Text("ACEL SETTINGS IOS VIP ACCES")
                                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                                    .tracking(1.8)
                                    .foregroundStyle(AppTheme.iosRed)
                            }
                        }

                        // MARK: - Login Card
                        VStack(alignment: .leading, spacing: 16) {
                            // Label
                            HStack(spacing: 6) {
                                Image(systemName: "key.fill")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundStyle(AppTheme.iosRed)
                                Text("ACCESS LICENSE KEY")
                                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                                    .tracking(1.2)
                                    .foregroundStyle(Color(white: 0.85))
                            }

                            // Text Input Field
                            ZStack(alignment: .trailing) {
                                TextField("Ketik key lisensi anda...", text: $key)
                                    .focused($keyFocused)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                                    .font(.system(size: 13, weight: .medium, design: .monospaced))
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 14)
                                    .background(Color(red: 18/255, green: 18/255, blue: 24/255))
                                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                                            .stroke(keyFocused ? AppTheme.iosRed : Color.white.opacity(0.1), lineWidth: 1)
                                    )

                                Image(systemName: "lock.fill")
                                    .font(.system(size: 14))
                                    .foregroundStyle(Color.white.opacity(0.3))
                                    .padding(.trailing, 14)
                            }

                            // Anti-Share Device Notice
                            HStack(spacing: 4) {
                                Image(systemName: "iphone.badge.checkmark")
                                    .font(.system(size: 10))
                                    .foregroundStyle(AppTheme.iosRed)
                                Text("Sistem 1 Key 1 Device Aktif • HWID Protected")
                                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                                    .foregroundStyle(Color.white.opacity(0.45))
                            }
                            .padding(.horizontal, 2)

                            // Verify & Enter Button
                            Button {
                                handleLogin()
                            } label: {
                                HStack(spacing: 8) {
                                    if manager.isBusy {
                                        ProgressView()
                                            .tint(.white)
                                        Text("MENGECEK SERVER...")
                                            .font(.system(size: 12, weight: .black, design: .monospaced))
                                            .tracking(1.8)
                                    } else {
                                        Text("VERIFY & ENTER")
                                            .font(.system(size: 12, weight: .black, design: .monospaced))
                                            .tracking(1.8)
                                        Image(systemName: "chevron.right")
                                            .font(.system(size: 12, weight: .bold))
                                    }
                                }
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(
                                    LinearGradient(
                                        colors: [AppTheme.iosRed, AppTheme.iosRedDark],
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                )
                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                .shadow(color: AppTheme.iosRed.opacity(0.4), radius: 12, x: 0, y: 4)
                            }
                            .disabled(manager.isBusy)
                            .buttonStyle(.plain)

                            // WhatsApp Admin Contact Button
                            Button {
                                if let url = URL(string: "https://wa.me/6285294242950") {
                                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                                }
                            } label: {
                                HStack(spacing: 8) {
                                    Image(systemName: "message.fill")
                                        .font(.system(size: 12, weight: .semibold))
                                        .foregroundStyle(AppTheme.emerald)
                                    Text("Dapatkan Key / Contact Admin")
                                        .font(.system(size: 11, weight: .semibold, design: .monospaced))
                                        .foregroundStyle(Color.white.opacity(0.85))
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 11)
                                .background(Color.white.opacity(0.05))
                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .stroke(Color.white.opacity(0.06), lineWidth: 1)
                                )
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(18)
                        .background(AppTheme.iosCard)
                        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 24, style: .continuous)
                                .stroke(Color.white.opacity(0.08), lineWidth: 1)
                        )
                        .offset(x: shakeOffset)

                        // Footer
                        HStack(spacing: 4) {
                            Text("DEVELOPER BY")
                                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                                .tracking(1.4)
                                .foregroundStyle(Color.white.opacity(0.45))
                            Text("HANX")
                                .font(.system(size: 11, weight: .black, design: .monospaced))
                                .tracking(1.4)
                                .foregroundStyle(AppTheme.iosRed)
                        }
                        .padding(.top, 12)
                        .padding(.bottom, 24)
                    }
                    .padding(.horizontal, 20)
                }
            }

            // MARK: - Dynamic Island Notification Toast
            if engine.showToast, let msg = engine.toastMessage {
                VStack {
                    HStack {
                        Text(msg)
                            .font(.system(size: 12, weight: .semibold, design: .monospaced))
                            .foregroundStyle(.white)
                        Spacer()
                        Text("ACEL-OS")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundStyle(AppTheme.iosRed)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .fill(engine.toastIsError ? Color(red: 0.35, green: 0.05, blue: 0.08).opacity(0.95) : Color(red: 26/255, green: 26/255, blue: 34/255).opacity(0.95))
                            .overlay(
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .stroke(AppTheme.iosRed.opacity(0.35), lineWidth: 1)
                            )
                    )
                    .shadow(color: Color.black.opacity(0.6), radius: 16, x: 0, y: 8)
                    .padding(.horizontal, 24)
                    .padding(.top, 10)
                    Spacer()
                }
                .transition(.move(edge: .top).combined(with: .opacity))
                .animation(.easeInOut(duration: 0.25), value: engine.showToast)
            }
        }
        .preferredColorScheme(.dark)
    }

    private func handleLogin() {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            shake()
            engine.showToast("Harap masukkan lisensi key!", isError: true)
            return
        }

        manager.activateWithFirebase(key: trimmed) { result in
            switch result {
            case .success(let msg):
                engine.showToast(msg, isError: false)
            case .failure(let err):
                shake()
                engine.showToast(err, isError: true)
            }
        }
    }

    private func shake() {
        withAnimation(.easeInOut(duration: 0.08).repeatCount(4, autoreverses: true)) {
            shakeOffset = 6
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
            shakeOffset = 0
        }
    }
}
