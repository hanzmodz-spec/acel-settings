# Cara Mengubah Source Code XoneOS Menjadi File .IPA

Karena Anda berada di **Windows**, compiler resmi iOS (**Xcode / xcodebuild**) tidak bisa diinstall langsung di sistem operasi Windows. 

Namun di dalam folder proyek Anda sudah tersedia file otomatisasi **GitHub Actions** (`.github/workflows/objective-c-xcode.yml`). Anda bisa memanfaatkan komputer Mac gratis milik server GitHub untuk mengompilasinya menjadi file `.ipa` hanya dalam waktu 2 menit.

---

## Cara 1: Menggunakan GitHub Actions (Paling Praktis, Cepat & Gratis)

### Langkah 1: Buat Repository di GitHub
1. Buka [github.com](https://github.com) dan login ke akun Anda.
2. Klik tombol **New** (Buat Repository Baru).
3. Beri nama (misal: `XoneOS`), pilih **Private** (agar source code Anda aman), lalu klik **Create repository**.

### Langkah 2: Upload Source Code
Ada 2 cara upload:
- **Cara A (Drag & Drop via Browser)**:
  - Di halaman repository baru Anda, klik tombol **"uploading an existing file"**.
  - Tarik (drag & drop) semua isi dari folder:  
    `D:\Downloads\Full source 3105 OG\letme-2-main`
  - Klik **Commit changes**.
- **Cara B (Lewat Git di Windows)**:
  ```powershell
  cd "D:\Downloads\Full source 3105 OG\letme-2-main"
  git init
  git branch -M main
  git add .
  git commit -m "feat: XoneOS initial release"
  git remote add origin https://github.com/USERNAME_ANDA/XoneOS.git
  git push -u origin main
  ```

### Langkah 3: Jalankan Kompilasi Otomatis
1. Di halaman repository GitHub Anda, klik tab **Actions** di bagian atas.
2. Di sebelah kiri, pilih workflow: **"Build unsigned IPA"**.
3. Di sebelah kanan, klik menu dropdown **"Run workflow"** &rarr; klik tombol hijau **"Run workflow"**.
4. Tunggu sekitar **1 - 2 menit**. Server Mac milik GitHub (`macos-15`) akan otomatis mengompilasi Swift, Objective-C, dan memaketkannya menjadi `.ipa`.

### Langkah 4: Download File .IPA
1. Setelah statusnya centang hijau (Success), klik riwayat build tersebut.
2. Scroll ke bagian paling bawah (**Artifacts**).
3. Klik file **`XoneOS-unsigned-ipa`** untuk langsung mengunduhnya ke PC Windows Anda.

---

## Cara 2: Install File .IPA yang Sudah Jadi ke iPhone

Setelah file `XoneOS.ipa` berhasil di-download ke PC Windows Anda:

1. Unduh dan buka **Sideloadly** di Windows: [sideloadly.io](https://sideloadly.io)
2. Sambungkan iPhone ke PC menggunakan kabel data USB.
3. Drag & drop file `XoneOS.ipa` ke kotak IPA di Sideloadly.
4. Masukkan **Apple ID** Anda di kolom yang tersedia.
5. Klik **Start**.
6. Selesai! Aplikasi **XoneOS** akan langsung muncul di layar utama iPhone Anda.

---

## Catatan Penting
- Bundle ID sudah otomatis tersetel ke **`com.xoneos.noelx`**.
- Nama aplikasi dan WhatsApp Channel Anda sudah tertanam permanen di dalam aplikasi.
